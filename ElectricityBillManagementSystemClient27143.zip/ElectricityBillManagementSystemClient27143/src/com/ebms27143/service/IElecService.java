package com.ebms27143.service;

import com.ebms27143.entity.*;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface IElecService extends Remote {

    // Authentication
    User authenticateUser(String username, String password) throws RemoteException;
    boolean verifyOtp(Long userId, String otp) throws RemoteException;
    void registerUser(User user) throws RemoteException;
    List<User> getAllUsers() throws RemoteException;
    User getUserById(Long id) throws RemoteException;
    void updateUser(User user) throws RemoteException;
    void updateUserWithPassword(User user) throws RemoteException;
    void deleteUser(Long userId) throws RemoteException;

    
    // Customer
void addCustomer(Customer customer) throws RemoteException;
void updateCustomer(Customer customer) throws RemoteException;
void deleteCustomer(Long customerId) throws RemoteException;
Customer getCustomerById(Long id) throws RemoteException;
List<Customer> getAllCustomers() throws RemoteException;

    // Tariff
    List<Tariff> getAllTariffs() throws RemoteException;

    // Bill
    List<Bill> getAllBills() throws RemoteException;
    List<Bill> getBillsByStatus(String status) throws RemoteException;
    Bill addMeterReadingAndGenerateBill(MeterReading reading, Long tariffId) throws RemoteException;
    boolean applyPenaltyIfOverdue(Long billId) throws RemoteException;
    void applyManualPenalty(Long billId, double penaltyAmount) throws RemoteException;
    void markBillAsPaid(Long billId) throws RemoteException;

    // Meter
    void addMeter(Meter meter) throws RemoteException;
    List<Meter> getAllMeters() throws RemoteException;
    List<Meter> getMetersByCustomer(Long customerId) throws RemoteException;
    void updateMeter(Meter meter) throws RemoteException;
    void deleteMeter(Long meterId) throws RemoteException;
    Meter getMeterById(Long id) throws RemoteException;

    // Payment
    void recordPayment(Payment payment) throws RemoteException;
    List<Payment> getAllPayments() throws RemoteException;
    List<Payment> getPaymentsByBill(Long billId) throws RemoteException;

    // Tariff CRUD
    void addTariff(Tariff tariff) throws RemoteException;
    void updateTariff(Tariff tariff) throws RemoteException;
    void deleteTariff(Long tariffId) throws RemoteException;
    Tariff getTariffById(Long id) throws RemoteException;

    // Reports
    List<Bill> getOverdueBills() throws RemoteException;
    List<Bill> getBillsByCustomer(Long customerId) throws RemoteException;

    // Notifications
    List<Notification> getRecentNotifications() throws RemoteException;

}