package com.ebms27143.client.service;

import com.ebms27143.service.IElecService;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class RMIClientConnector {

    private static IElecService service;

    public static IElecService getService() {
        try {
            if (service == null) {
                service = (IElecService) Naming.lookup("rmi://localhost:5000/ebms");
            }
        } catch (MalformedURLException | NotBoundException | RemoteException e) {
        }
        return service;
    }
}