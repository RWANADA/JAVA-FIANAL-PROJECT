package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Notification;
import com.ebms27143.entity.User;
import com.ebms27143.service.IElecService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class DashboardFrame extends JFrame {

    private static final Color NAVY      = UITheme.NAVY;
    private static final Color NAVY_DARK = UITheme.NAVY_DARK;
    private static final Color BLUE      = UITheme.BLUE;
    private static final Color ACCENT    = UITheme.ACCENT;
    private static final Color WHITE     = UITheme.WHITE;
    private static final Color BG        = UITheme.BG;
    private static final Color TEXT_DARK = UITheme.TEXT_DARK;
    private static final Color TEXT_GRAY = UITheme.TEXT_GRAY;

    // Quick-access card accent colors
    private static final Color[] CARD_COLORS = {
        UITheme.BLUE,
        UITheme.TEAL,
        UITheme.PURPLE,
        new Color(183, 28, 28),
        UITheme.ORANGE,
        new Color(27, 94, 32),
        new Color(13, 71, 161),
        new Color(74, 20, 140),
    };

    // Sidebar menu definition: {label, icon-letter, group}
    private static final String[][] MENU = {
        {"Dashboard",      "D", "OVERVIEW"},
        {"Customers",      "C", "MANAGEMENT"},
        {"Meters",         "M", "MANAGEMENT"},
        {"Meter Readings", "R", "MANAGEMENT"},
        {"Bills",          "B", "MANAGEMENT"},
        {"Payments",       "P", "MANAGEMENT"},
        {"Tariffs",        "T", "MANAGEMENT"},
        {"Reports",        "A", "ANALYTICS"},
        {"Users",          "U", "ANALYTICS"},
    };

    private JPanel  contentPanel;
    private JLabel  lblPageTitle;
    private User    loggedInUser;
    private JButton activeBtn  = null;
    private JButton bellButton;
    private JDialog notifPopup;
    private List<Notification> cachedNotifs = new ArrayList<>();
    private int unreadCount = 0;

    public DashboardFrame(User user) {
        this.loggedInUser = user;
        setTitle("EBMS — Electricity Bill Management System");
        setSize(1120, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(UITheme.createAppIcon(64));
        setLayout(new BorderLayout());
        getContentPane().setBackground(BG);

        add(buildSidebar(), BorderLayout.WEST);

        JPanel mainArea = new JPanel(new BorderLayout());
        mainArea.setBackground(BG);
        mainArea.add(buildTopBar(), BorderLayout.NORTH);

        contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(BG);
        contentPanel.setBorder(new EmptyBorder(22, 26, 22, 26));
        contentPanel.add(buildDashboardContent(), BorderLayout.CENTER);
        mainArea.add(contentPanel, BorderLayout.CENTER);

        mainArea.add(UITheme.makeStatusBar(
                "Electricity Bill Management System  |  AUCA INSY 7312  |  © 2026 Iradukunda Kubana Christian"),
                BorderLayout.SOUTH);
        add(mainArea, BorderLayout.CENTER);
        startNotifPoller();
    }

    public DashboardFrame() { this(null); }

    // ── Sidebar ───────────────────────────────────────────────────────────
    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, NAVY_DARK, 0, getHeight(), new Color(8, 28, 75)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setOpaque(false);
        sidebar.setPreferredSize(new Dimension(228, 700));

        // ── Logo area ──
        JPanel logoArea = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(0, 0, 0, 55));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        logoArea.setOpaque(false);
        logoArea.setMaximumSize(new Dimension(228, 88));
        logoArea.setPreferredSize(new Dimension(228, 88));
        logoArea.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(255, 255, 255, 18)));

        GridBagConstraints lgbc = new GridBagConstraints();
        lgbc.gridx = 0; lgbc.gridy = 0;
        // Custom bolt icon panel
        JPanel boltPanel = UITheme.makeBoltIcon(34, new Color(255, 255, 255, 22), ACCENT);
        logoArea.add(boltPanel, lgbc);

        lgbc.gridx = 1;
        lgbc.insets = new Insets(0, 10, 0, 0);
        JPanel logoText = new JPanel();
        logoText.setLayout(new BoxLayout(logoText, BoxLayout.Y_AXIS));
        logoText.setOpaque(false);
        JLabel lblName = new JLabel("EBMS");
        lblName.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblName.setForeground(WHITE);
        JLabel lblSub = new JLabel("Bill Management");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblSub.setForeground(new Color(140, 175, 215));
        logoText.add(lblName);
        logoText.add(lblSub);
        logoArea.add(logoText, lgbc);
        sidebar.add(logoArea);
        sidebar.add(Box.createVerticalStrut(8));

        // ── Menu items ──
        String lastGroup = "";
        for (String[] item : MENU) {
            String group = item[2];
            if (!group.equals(lastGroup)) {
                if (!lastGroup.isEmpty()) sidebar.add(Box.createVerticalStrut(10));
                sidebar.add(groupLabel(group));
                lastGroup = group;
            }
            JButton btn = makeSidebarBtn(item[0], item[1]);
            final String lbl = item[0];
            btn.addActionListener(e -> handleMenu(lbl, btn));
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(5));
        }

        sidebar.add(Box.createVerticalGlue());

        // ── User / logout strip ──
        JPanel userArea = new JPanel(new BorderLayout(10, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(0, 0, 0, 55));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        userArea.setOpaque(false);
        userArea.setMaximumSize(new Dimension(228, 62));
        userArea.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(255, 255, 255, 18)),
                new EmptyBorder(10, 18, 10, 12)));

        String uname = loggedInUser != null ? loggedInUser.getUsername() : "User";
        String role  = loggedInUser != null && loggedInUser.getRole() != null ? loggedInUser.getRole() : "STAFF";

        // Avatar circle
        JPanel avatar = UITheme.makeLetterIcon(uname.substring(0, 1).toUpperCase(), 32,
                new Color(255, 255, 255, 22), ACCENT);
        userArea.add(avatar, BorderLayout.WEST);

        JPanel namePanel = new JPanel();
        namePanel.setOpaque(false);
        namePanel.setLayout(new BoxLayout(namePanel, BoxLayout.Y_AXIS));
        JLabel lblUname = new JLabel(uname);
        lblUname.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblUname.setForeground(WHITE);
        JLabel lblRole = new JLabel(role);
        lblRole.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblRole.setForeground(ACCENT);
        namePanel.add(lblUname);
        namePanel.add(lblRole);
        userArea.add(namePanel, BorderLayout.CENTER);

        // Logout button — text only
        JButton btnLogout = new JButton("Exit") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (!getBackground().equals(NAVY_DARK)) {
                    g2.setColor(getBackground());
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 6, 6);
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 10));
        btnLogout.setForeground(new Color(255, 100, 100));
        btnLogout.setBackground(NAVY_DARK);
        btnLogout.setFocusPainted(false);
        btnLogout.setContentAreaFilled(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setOpaque(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.setPreferredSize(new Dimension(40, 28));
        btnLogout.setBorder(BorderFactory.createLineBorder(new Color(255, 80, 80, 80), 1));
        btnLogout.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnLogout.setBackground(new Color(255, 80, 80, 40)); btnLogout.repaint(); }
            public void mouseExited(MouseEvent e)  { btnLogout.setBackground(NAVY_DARK);                  btnLogout.repaint(); }
        });
        btnLogout.addActionListener(e -> {
            int c = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (c == JOptionPane.YES_OPTION) { new LoginFrame().setVisible(true); dispose(); }
        });
        userArea.add(btnLogout, BorderLayout.EAST);
        sidebar.add(userArea);
        return sidebar;
    }

    private JLabel groupLabel(String title) {
        JLabel lbl = new JLabel(title, SwingConstants.CENTER);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 9));
        lbl.setForeground(new Color(90, 130, 180));
        lbl.setMaximumSize(new Dimension(228, 22));
        lbl.setBorder(new EmptyBorder(2, 0, 2, 0));
        return lbl;
    }

    private JButton makeSidebarBtn(String label, String iconLetter) {
        JButton btn = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color bg = getBackground();
                if (!bg.equals(NAVY_DARK)) {
                    g2.setColor(bg);
                    g2.fillRoundRect(6, 2, getWidth() - 12, getHeight() - 4, 8, 8);
                }
                g2.dispose();

                // Draw letter icon + label centered horizontally
                int iconSize = 22;
                int gap = 10;
                Graphics2D gMeasure = (Graphics2D) g.create();
                gMeasure.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                int textWidth = gMeasure.getFontMetrics().stringWidth(label);
                gMeasure.dispose();
                int totalWidth = iconSize + gap + textWidth;
                int ix = (getWidth() - totalWidth) / 2;
                int iy = (getHeight() - iconSize) / 2;

                g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Color isBg = this == activeBtn
                        ? new Color(255, 193, 7, 40)
                        : new Color(255, 255, 255, 16);
                g2.setColor(isBg);
                g2.fillRoundRect(ix, iy, iconSize, iconSize, 5, 5);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 11));
                g2.setColor(this == activeBtn ? ACCENT : new Color(180, 210, 240));
                FontMetrics fm = g2.getFontMetrics();
                int tx = ix + (iconSize - fm.stringWidth(iconLetter)) / 2;
                int ty = iy + (iconSize + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(iconLetter, tx, ty);
                g2.dispose();

                // Draw label text
                g = g.create();
                Graphics2D g3 = (Graphics2D) g;
                g3.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                g3.setColor(getForeground());
                g3.drawString(label, ix + iconSize + gap, getHeight() / 2 + g3.getFontMetrics().getAscent() / 2 - 1);
                g3.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setForeground(new Color(180, 210, 235));
        btn.setBackground(NAVY_DARK);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        btn.setMaximumSize(new Dimension(228, 40));
        btn.setPreferredSize(new Dimension(228, 40));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                if (btn != activeBtn) {
                    btn.setBackground(new Color(255, 255, 255, 14));
                    btn.setForeground(WHITE);
                }
            }
            public void mouseExited(MouseEvent e) {
                if (btn != activeBtn) {
                    btn.setBackground(NAVY_DARK);
                    btn.setForeground(new Color(180, 210, 235));
                }
            }
        });
        return btn;
    }

    // ── Top bar ───────────────────────────────────────────────────────────
    private JPanel buildTopBar() {
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setBackground(WHITE);
        topBar.setPreferredSize(new Dimension(892, 56));
        topBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CLR),
                new EmptyBorder(0, 24, 0, 24)));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 4, 0));
        left.setBackground(WHITE);
        JLabel slash = new JLabel("/  ");
        slash.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        slash.setForeground(TEXT_GRAY);
        lblPageTitle = new JLabel("Dashboard");
        lblPageTitle.setFont(new Font("Segoe UI", Font.BOLD, 15));
        lblPageTitle.setForeground(NAVY);
        left.add(slash);
        left.add(lblPageTitle);
        topBar.add(left, BorderLayout.WEST);

        String uname = loggedInUser != null ? loggedInUser.getUsername() : "User";
        String role  = loggedInUser != null && loggedInUser.getRole() != null ? loggedInUser.getRole() : "";
        JPanel rightTop = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        rightTop.setBackground(WHITE);

        bellButton = makeBellButton();
        rightTop.add(bellButton);
        JSeparator sep = new JSeparator(SwingConstants.VERTICAL);
        sep.setPreferredSize(new Dimension(1, 24));
        sep.setForeground(UITheme.BORDER_CLR);
        rightTop.add(sep);

        if (!role.isEmpty()) {
            JLabel lblR = new JLabel(role);
            lblR.setFont(new Font("Segoe UI", Font.BOLD, 10));
            lblR.setForeground(WHITE);
            lblR.setBackground(BLUE);
            lblR.setOpaque(true);
            lblR.setBorder(new EmptyBorder(3, 9, 3, 9));
            rightTop.add(lblR);
        }
        JLabel lblU = new JLabel(uname);
        lblU.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblU.setForeground(NAVY);
        rightTop.add(UITheme.makeLetterIcon(uname.substring(0, 1).toUpperCase(), 28, NAVY, WHITE));
        rightTop.add(lblU);
        topBar.add(rightTop, BorderLayout.EAST);
        return topBar;
    }

    // ── Dashboard content ─────────────────────────────────────────────────
    private JPanel buildDashboardContent() {
        JPanel wrap = new JPanel(new BorderLayout(0, 18));
        wrap.setBackground(BG);
        wrap.setOpaque(false);

        // Greeting
        JPanel headRow = new JPanel(new BorderLayout());
        headRow.setOpaque(false);
        String uname = loggedInUser != null ? loggedInUser.getUsername() : "User";
        JLabel lblWelcome = new JLabel("Welcome back, " + uname);
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 19));
        lblWelcome.setForeground(NAVY);
        JLabel lblDate = new JLabel(
                new java.text.SimpleDateFormat("EEEE, dd MMMM yyyy").format(new java.util.Date()));
        lblDate.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDate.setForeground(TEXT_GRAY);
        headRow.add(lblWelcome, BorderLayout.WEST);
        headRow.add(lblDate, BorderLayout.EAST);
        wrap.add(headRow, BorderLayout.NORTH);

        JPanel centerWrap = new JPanel(new BorderLayout(0, 18));
        centerWrap.setOpaque(false);

        // Stat bar
        JPanel statBar = new JPanel(new GridLayout(1, 4, 10, 0));
        statBar.setOpaque(false);
        statBar.setPreferredSize(new Dimension(0, 68));
        statBar.add(UITheme.makeStatCard("C", "Customers",   "—", BLUE));
        statBar.add(UITheme.makeStatCard("B", "Total Bills", "—", UITheme.TEAL));
        statBar.add(UITheme.makeStatCard("P", "Payments",    "—", UITheme.PURPLE));
        statBar.add(UITheme.makeStatCard("M", "Meters",      "—", NAVY));
        centerWrap.add(statBar, BorderLayout.NORTH);

        // Quick-access section
        JPanel gridSection = new JPanel(new BorderLayout(0, 12));
        gridSection.setOpaque(false);
        JLabel lblSection = new JLabel("Quick Access");
        lblSection.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSection.setForeground(NAVY);
        lblSection.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 3, 0, 0, BLUE),
                new EmptyBorder(2, 10, 2, 0)));
        gridSection.add(lblSection, BorderLayout.NORTH);

        JPanel grid = new JPanel(new GridLayout(2, 4, 10, 10));
        grid.setOpaque(false);
        String[][] items = {
            {"C", "Customers",      "Manage customer accounts"},
            {"M", "Meters",         "Register & manage meters"},
            {"R", "Meter Readings", "Enter monthly readings"},
            {"B", "Bills",          "View & manage bills"},
            {"P", "Payments",       "Record payments"},
            {"T", "Tariffs",        "Manage tariff rates"},
            {"A", "Reports",        "Generate & export reports"},
            {"U", "Users",          "Manage system users"},
        };
        for (int i = 0; i < items.length; i++) {
            grid.add(makeQuickCard(items[i][0], items[i][1], items[i][2], CARD_COLORS[i]));
        }
        gridSection.add(grid, BorderLayout.CENTER);
        centerWrap.add(gridSection, BorderLayout.CENTER);
        wrap.add(centerWrap, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel makeQuickCard(String letter, String title, String desc, Color accent) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                // shadow
                g2.setColor(new Color(0, 0, 0, 9));
                g2.fillRoundRect(2, 3, getWidth() - 2, getHeight() - 2, 10, 10);
                // body
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 3, 10, 10);
                // top stripe
                g2.setColor(accent);
                g2.fillRoundRect(0, 0, getWidth() - 2, 5, 4, 4);
                g2.dispose();
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(WHITE);
        card.setBorder(new EmptyBorder(10, 12, 10, 12));
        card.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Letter icon circle
        JPanel iconPanel = UITheme.makeLetterIcon(letter, 28, new Color(
                accent.getRed(), accent.getGreen(), accent.getBlue(), 22), accent);
        iconPanel.setAlignmentX(LEFT_ALIGNMENT);
        card.add(iconPanel);
        card.add(Box.createVerticalStrut(6));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblTitle.setForeground(TEXT_DARK);
        lblTitle.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblTitle);
        card.add(Box.createVerticalStrut(2));

        JLabel lblDesc = new JLabel("<html>" + desc + "</html>");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblDesc.setForeground(TEXT_GRAY);
        lblDesc.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblDesc);

        card.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { card.setBackground(new Color(247, 251, 255)); card.repaint(); }
            public void mouseExited(MouseEvent e)  { card.setBackground(WHITE);                   card.repaint(); }
            public void mouseClicked(MouseEvent e) { handleMenu(title, null); }
        });
        return card;
    }

    // ── Notification bell ─────────────────────────────────────────────────
    private JButton makeBellButton() {
        JButton bell = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (!getBackground().equals(WHITE)) {
                    g2.setColor(getBackground());
                    g2.fillOval(2, 2, getWidth() - 4, getHeight() - 4);
                }
                int w = getWidth(), h = getHeight();
                int bx = 9, by = 6, bw = w - 18, bh = h - 14;
                g2.setColor(NAVY);
                g2.fillOval(w / 2 - 2, by - 3, 5, 4);
                g2.fillArc(bx, by, bw, bh, 0, 180);
                int[] xs = {bx - 3, bx + bw + 3, bx + bw, bx};
                int[] ys = {by + bh / 2, by + bh / 2, by + bh - 2, by + bh - 2};
                g2.fillPolygon(xs, ys, 4);
                g2.fillRoundRect(bx - 4, by + bh - 3, bw + 8, 3, 2, 2);
                g2.fillOval(w / 2 - 2, by + bh - 1, 5, 5);
                if (unreadCount > 0) {
                    g2.setColor(new Color(220, 38, 38));
                    g2.fillOval(w - 14, 3, 12, 12);
                    g2.setColor(Color.WHITE);
                    g2.setFont(new Font("Segoe UI", Font.BOLD, 8));
                    String cnt = unreadCount > 9 ? "9+" : String.valueOf(unreadCount);
                    FontMetrics fm = g2.getFontMetrics();
                    g2.drawString(cnt,
                            w - 14 + (12 - fm.stringWidth(cnt)) / 2,
                            3 + (12 + fm.getAscent() - fm.getDescent()) / 2);
                }
                g2.dispose();
            }
        };
        bell.setPreferredSize(new Dimension(36, 36));
        bell.setFocusPainted(false);
        bell.setBorderPainted(false);
        bell.setContentAreaFilled(false);
        bell.setOpaque(false);
        bell.setBackground(WHITE);
        bell.setCursor(new Cursor(Cursor.HAND_CURSOR));
        bell.setToolTipText("Notifications");
        bell.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { bell.setBackground(new Color(235, 245, 255)); bell.repaint(); }
            public void mouseExited(MouseEvent e)  { bell.setBackground(WHITE);                   bell.repaint(); }
        });
        bell.addActionListener(e -> {
            // Fetch fresh data every time bell is clicked
            try {
                IElecService svc = RMIClientConnector.getService();
                if (svc != null) {
                    List<Notification> fresh = svc.getRecentNotifications();
                    if (fresh != null) cachedNotifs = fresh;
                }
            } catch (Exception ex) {
                System.err.println("[NOTIF] Fetch failed: " + ex.getMessage());
            }
            toggleNotifPopup(bell);
        });
        return bell;
    }

    private void toggleNotifPopup(JButton anchor) {
        if (notifPopup != null && notifPopup.isVisible()) {
            notifPopup.dispose();
            notifPopup = null;
            return;
        }
        unreadCount = 0;
        anchor.repaint();

        notifPopup = new JDialog(this, false);
        notifPopup.setUndecorated(true);
        notifPopup.getRootPane().setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR, 1));

        JPanel panel = new JPanel(new BorderLayout(0, 0));
        panel.setBackground(WHITE);

        // Blue top stripe + header combined into NORTH
        JPanel north = new JPanel(new BorderLayout());
        north.setBackground(WHITE);
        JPanel stripe = new JPanel();
        stripe.setBackground(BLUE);
        stripe.setPreferredSize(new Dimension(0, 4));
        north.add(stripe, BorderLayout.NORTH);

        JPanel hdr = new JPanel(new BorderLayout());
        hdr.setBackground(WHITE);
        hdr.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CLR),
                new EmptyBorder(10, 14, 10, 14)));
        JLabel lblTitle = new JLabel("Notifications");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblTitle.setForeground(NAVY);
        hdr.add(lblTitle, BorderLayout.WEST);
        JLabel lblCnt = new JLabel(cachedNotifs.size() + " recent");
        lblCnt.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblCnt.setForeground(TEXT_GRAY);
        hdr.add(lblCnt, BorderLayout.EAST);
        north.add(hdr, BorderLayout.CENTER);
        panel.add(north, BorderLayout.NORTH);

        // Notifications list
        JPanel listPanel = new JPanel();
        listPanel.setBackground(WHITE);
        listPanel.setLayout(new BoxLayout(listPanel, BoxLayout.Y_AXIS));

        if (cachedNotifs.isEmpty()) {
            JPanel emptyWrap = new JPanel(new GridBagLayout());
            emptyWrap.setBackground(WHITE);
            emptyWrap.setPreferredSize(new Dimension(310, 90));
            JLabel empty = new JLabel("No notifications yet");
            empty.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            empty.setForeground(TEXT_GRAY);
            emptyWrap.add(empty);
            listPanel.add(emptyWrap);
        } else {
            for (Notification n : cachedNotifs) {
                listPanel.add(makeNotifRow(n));
            }
        }

        JScrollPane scroll = new JScrollPane(listPanel);
        scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        int listH = cachedNotifs.isEmpty() ? 90 : Math.min(cachedNotifs.size() * 64, 280);
        scroll.setPreferredSize(new Dimension(310, listH));
        panel.add(scroll, BorderLayout.CENTER);

        notifPopup.add(panel);
        notifPopup.pack();

        Point loc = anchor.getLocationOnScreen();
        int popW = notifPopup.getWidth();
        notifPopup.setLocation(loc.x + anchor.getWidth() - popW, loc.y + anchor.getHeight() + 4);
        notifPopup.setVisible(true);

        notifPopup.addWindowFocusListener(new java.awt.event.WindowFocusListener() {
            public void windowGainedFocus(java.awt.event.WindowEvent e) {}
            public void windowLostFocus(java.awt.event.WindowEvent e) {
                SwingUtilities.invokeLater(() -> {
                    if (notifPopup != null) { notifPopup.dispose(); notifPopup = null; }
                });
            }
        });
    }

    private JPanel makeNotifRow(Notification n) {
        String type = n.getType() != null ? n.getType() : "INFO";
        Color tagColor = type.contains("OVERDUE") ? new Color(220, 38, 38)
                       : type.contains("PAYMENT") ? new Color(22, 101, 52)
                       : BLUE;

        JPanel row = new JPanel(new BorderLayout(10, 0));
        row.setOpaque(true);
        row.setBackground(WHITE);
        row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(240, 244, 248)),
                new EmptyBorder(8, 14, 8, 14)));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 62));
        row.setAlignmentX(LEFT_ALIGNMENT);

        JPanel dot = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(tagColor);
                g2.fillOval(0, (getHeight() - 8) / 2, 8, 8);
                g2.dispose();
            }
        };
        dot.setOpaque(false);
        dot.setPreferredSize(new Dimension(10, 10));
        row.add(dot, BorderLayout.WEST);

        JPanel text = new JPanel();
        text.setOpaque(false);
        text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
        JLabel lblType = new JLabel(type.replace("_", " "));
        lblType.setFont(new Font("Segoe UI", Font.BOLD, 10));
        lblType.setForeground(tagColor);
        lblType.setAlignmentX(LEFT_ALIGNMENT);
        text.add(lblType);
        String msg = n.getMessage() != null ? n.getMessage() : "";
        JLabel lblMsg = new JLabel("<html><body style='width:195px'>" + msg + "</body></html>");
        lblMsg.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblMsg.setForeground(TEXT_DARK);
        lblMsg.setAlignmentX(LEFT_ALIGNMENT);
        text.add(lblMsg);
        row.add(text, BorderLayout.CENTER);

        if (n.getSentAt() != null) {
            JLabel time = new JLabel(new java.text.SimpleDateFormat("HH:mm").format(n.getSentAt()));
            time.setFont(new Font("Segoe UI", Font.PLAIN, 9));
            time.setForeground(TEXT_GRAY);
            row.add(time, BorderLayout.EAST);
        }

        row.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { row.setBackground(new Color(247, 251, 255)); row.repaint(); }
            public void mouseExited(MouseEvent e)  { row.setBackground(WHITE);                   row.repaint(); }
        });
        return row;
    }

    private void fetchNotifications() {
        new Thread(() -> {
            try {
                IElecService svc = RMIClientConnector.getService();
                if (svc == null) {
                    System.err.println("[NOTIF] RMI service is null — server not connected");
                    return;
                }
                List<Notification> list = svc.getRecentNotifications();
                int prev = cachedNotifs.size();
                cachedNotifs = list != null ? list : new ArrayList<>();
                if (cachedNotifs.size() > prev) unreadCount += (cachedNotifs.size() - prev);
                System.out.println("[NOTIF] Fetched " + cachedNotifs.size() + " notifications");
                SwingUtilities.invokeLater(() -> { if (bellButton != null) bellButton.repaint(); });
            } catch (Exception e) {
                System.err.println("[NOTIF] Error: " + e.getMessage());
            }
        }).start();
    }

    private void startNotifPoller() {
        fetchNotifications();
        new javax.swing.Timer(30_000, e -> fetchNotifications()).start();
    }

    private void handleMenu(String menu, JButton src) {
        if (activeBtn != null) {
            activeBtn.setBackground(NAVY_DARK);
            activeBtn.setForeground(new Color(180, 210, 235));
        }
        if (src != null) {
            src.setBackground(new Color(255, 255, 255, 20));
            src.setForeground(WHITE);
            activeBtn = src;
        }
        lblPageTitle.setText(menu);
        switch (menu) {
            case "Customers":      new CustomerManagementFrame().setVisible(true);  break;
            case "Meters":         new MeterManagementFrame().setVisible(true);     break;
            case "Meter Readings": new MeterReadingFrame().setVisible(true);        break;
            case "Bills":          new BillManagementFrame().setVisible(true);      break;
            case "Payments":       new BillManagementFrame().setVisible(true);      break;
            case "Tariffs":        new TariffManagementFrame().setVisible(true);    break;
            case "Reports":        new ReportFrame().setVisible(true);              break;
            case "Users":          new UserManagementFrame().setVisible(true);      break;
            case "Dashboard":
                contentPanel.removeAll();
                contentPanel.add(buildDashboardContent(), BorderLayout.CENTER);
                contentPanel.revalidate();
                contentPanel.repaint();
                lblPageTitle.setText("Dashboard");
                break;
        }
    }
}
