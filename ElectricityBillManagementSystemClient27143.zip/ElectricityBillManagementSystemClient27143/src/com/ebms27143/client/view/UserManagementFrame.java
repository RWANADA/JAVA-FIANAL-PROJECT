package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class UserManagementFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtUsername, txtEmail, txtSearch;
    private JPasswordField txtPassword;
    private JComboBox<String> cmbRole;

    public UserManagementFrame() {
        setTitle("User Management");
        setSize(960, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("U", "User Management", "Manage system users, roles and access"), BorderLayout.NORTH);

        // ── CENTER: search + table ──
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(12, 14, 0, 14));

        txtSearch = UITheme.makeField(20);
        JButton btnSearch = UITheme.solidBtn("Search", UITheme.BLUE, UITheme.WHITE);
        center.add(UITheme.makeSearchBar(txtSearch, btnSearch), BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Username", "Role", "Email"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ── SOUTH: form + buttons ──
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setBackground(UITheme.BG);
        south.setBorder(new EmptyBorder(10, 14, 6, 14));

        JPanel formCard = UITheme.makeCard();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        txtUsername = UITheme.makeField(14);
        txtPassword = UITheme.makePasswordField(14);
        txtEmail    = UITheme.makeField(14);
        cmbRole     = UITheme.makeCombo(new String[]{"ADMIN", "STAFF"});

        g.gridx = 0; g.gridy = 0; formCard.add(UITheme.fieldLabel("Username:"), g);
        g.gridx = 1; formCard.add(txtUsername, g);
        g.gridx = 2; formCard.add(UITheme.fieldLabel("Password:"), g);
        g.gridx = 3; formCard.add(txtPassword, g);

        g.gridx = 0; g.gridy = 1; formCard.add(UITheme.fieldLabel("Email:"), g);
        g.gridx = 1; formCard.add(txtEmail, g);
        g.gridx = 2; formCard.add(UITheme.fieldLabel("Role:"), g);
        g.gridx = 3; formCard.add(cmbRole, g);

        south.add(UITheme.sectionLabel("User Details"), BorderLayout.NORTH);
        south.add(formCard, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        btnRow.setBackground(UITheme.BG);
        JButton btnAdd    = UITheme.solidBtn("Add User", UITheme.GREEN,     UITheme.WHITE);
        JButton btnUpdate = UITheme.solidBtn("Update",   UITheme.BLUE,      UITheme.WHITE);
        JButton btnDelete = UITheme.solidBtn("Delete",   UITheme.RED,       UITheme.WHITE);
        JButton btnRefresh= UITheme.solidBtn("Refresh",  UITheme.NAVY,      UITheme.WHITE);
        JButton btnClear  = UITheme.outlineBtn("Clear",  UITheme.TEXT_GRAY);
        btnRow.add(btnAdd); btnRow.add(btnUpdate); btnRow.add(btnDelete); btnRow.add(btnRefresh); btnRow.add(btnClear);
        south.add(btnRow, BorderLayout.SOUTH);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(south, BorderLayout.CENTER);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  User Management"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> addUser());
        btnUpdate.addActionListener(e -> updateUser());
        btnDelete.addActionListener(e -> deleteUser());
        btnRefresh.addActionListener(e -> loadUsers());
        btnClear.addActionListener(e -> clearForm());
        btnSearch.addActionListener(e -> searchUsers(txtSearch.getText()));
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) populateForm(); });

        loadUsers();
    }

    private void loadUsers() {
        try {
            model.setRowCount(0);
            for (User u : RMIClientConnector.getService().getAllUsers()) addRow(u);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error loading users!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void addRow(User u) {
        model.addRow(new Object[]{u.getId(), u.getUsername(), u.getRole(), u.getEmail()});
    }

    private void searchUsers(String query) {
        try {
            model.setRowCount(0);
            for (User u : RMIClientConnector.getService().getAllUsers())
                if (u.getUsername().toLowerCase().contains(query.toLowerCase())
                        || (u.getEmail() != null && u.getEmail().toLowerCase().contains(query.toLowerCase()))
                        || (u.getRole() != null && u.getRole().toLowerCase().contains(query.toLowerCase())))
                    addRow(u);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void populateForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        txtUsername.setText(model.getValueAt(row, 1).toString());
        txtPassword.setText("");
        cmbRole.setSelectedItem(model.getValueAt(row, 2) != null ? model.getValueAt(row, 2).toString() : "STAFF");
        txtEmail.setText(model.getValueAt(row, 3) != null ? model.getValueAt(row, 3).toString() : "");
    }

    private boolean validateForm(boolean requirePwd) {
        String user = txtUsername.getText().trim(), email = txtEmail.getText().trim(),
               pwd  = new String(txtPassword.getPassword()).trim();
        if (user.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and Email are required!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (user.length() < 3) {
            JOptionPane.showMessageDialog(this, "Username must be at least 3 characters!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (requirePwd && pwd.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Password is required!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (requirePwd && pwd.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password must be at least 4 characters!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!email.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email address!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        return true;
    }

    private void addUser() {
        if (!validateForm(true)) return;
        try {
            User u = new User();
            u.setUsername(txtUsername.getText().trim());
            u.setPasswordHash(new String(txtPassword.getPassword()).trim());
            u.setEmail(txtEmail.getText().trim());
            u.setRole(cmbRole.getSelectedItem().toString());
            RMIClientConnector.getService().registerUser(u);
            loadUsers(); clearForm();
            JOptionPane.showMessageDialog(this, "User added successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void updateUser() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a user first!"); return; }
        if (!validateForm(false)) return;
        try {
            Long id = Long.valueOf(model.getValueAt(row, 0).toString());
            User u = RMIClientConnector.getService().getUserById(id);
            u.setUsername(txtUsername.getText().trim());
            u.setEmail(txtEmail.getText().trim());
            u.setRole(cmbRole.getSelectedItem().toString());
            String pwd = new String(txtPassword.getPassword()).trim();
            if (!pwd.isEmpty()) {
                if (pwd.length() < 4) { JOptionPane.showMessageDialog(this, "Password must be at least 4 characters!", "Validation", JOptionPane.WARNING_MESSAGE); return; }
                u.setPasswordHash(pwd);
                RMIClientConnector.getService().updateUserWithPassword(u);
            } else {
                RMIClientConnector.getService().updateUser(u);
            }
            loadUsers(); clearForm();
            JOptionPane.showMessageDialog(this, "User updated successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void deleteUser() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a user first!"); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this user?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            RMIClientConnector.getService().deleteUser(Long.valueOf(model.getValueAt(row, 0).toString()));
            loadUsers(); clearForm();
            JOptionPane.showMessageDialog(this, "User deleted successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void clearForm() {
        txtUsername.setText(""); txtPassword.setText(""); txtEmail.setText("");
        cmbRole.setSelectedIndex(0); table.clearSelection();
    }
}
