package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Tariff;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.util.List;

public class TariffManagementFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtName, txtRate, txtSearch;
    private JComboBox<String> cmbCategory;

    public TariffManagementFrame() {
        setTitle("Tariff Management");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("T", "Tariff Management", "Manage electricity tariff rates by category"), BorderLayout.NORTH);

        // ── CENTER: search + table ──
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(12, 14, 0, 14));

        txtSearch = UITheme.makeField(20);
        JButton btnSearch = UITheme.solidBtn("Search", UITheme.BLUE, UITheme.WHITE);
        center.add(UITheme.makeSearchBar(txtSearch, btnSearch), BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Name", "Category", "Rate Per Unit (RWF)", "Effective Date"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ── SOUTH: form + buttons ──
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setBackground(UITheme.BG);
        south.setBorder(new EmptyBorder(10, 14, 6, 14));

        JPanel formCard = UITheme.makeCard();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        txtName = UITheme.makeField(14);
        txtRate = UITheme.makeField(14);
        cmbCategory = UITheme.makeCombo(new String[]{"Residential", "Commercial", "Industrial"});

        g.gridx = 0; g.gridy = 0; formCard.add(UITheme.fieldLabel("Name:"), g);
        g.gridx = 1; formCard.add(txtName, g);
        g.gridx = 2; formCard.add(UITheme.fieldLabel("Category:"), g);
        g.gridx = 3; formCard.add(cmbCategory, g);

        g.gridx = 0; g.gridy = 1; formCard.add(UITheme.fieldLabel("Rate Per Unit (RWF):"), g);
        g.gridx = 1; formCard.add(txtRate, g);

        south.add(UITheme.sectionLabel("Tariff Details"), BorderLayout.NORTH);
        south.add(formCard, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        btnRow.setBackground(UITheme.BG);
        JButton btnAdd    = UITheme.solidBtn("Add",     UITheme.GREEN, UITheme.WHITE);
        JButton btnUpdate = UITheme.solidBtn("Update",  UITheme.BLUE,  UITheme.WHITE);
        JButton btnDelete = UITheme.solidBtn("Delete",  UITheme.RED,   UITheme.WHITE);
        JButton btnRefresh= UITheme.solidBtn("Refresh", UITheme.NAVY,  UITheme.WHITE);
        btnRow.add(btnAdd); btnRow.add(btnUpdate); btnRow.add(btnDelete); btnRow.add(btnRefresh);
        south.add(btnRow, BorderLayout.SOUTH);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(south, BorderLayout.CENTER);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  Tariff Management"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> addTariff());
        btnUpdate.addActionListener(e -> updateTariff());
        btnDelete.addActionListener(e -> deleteTariff());
        btnRefresh.addActionListener(e -> loadTariffs());
        btnSearch.addActionListener(e -> searchTariffs(txtSearch.getText()));
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) populateForm(); });

        loadTariffs();
    }

    private void loadTariffs() {
        try {
            model.setRowCount(0);
            for (Tariff t : RMIClientConnector.getService().getAllTariffs()) addRow(t);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error loading tariffs!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void addRow(Tariff t) {
        model.addRow(new Object[]{t.getId(), t.getName(), t.getCategory(), t.getRatePerUnit(), t.getEffectiveDate()});
    }

    private void searchTariffs(String query) {
        try {
            model.setRowCount(0);
            for (Tariff t : RMIClientConnector.getService().getAllTariffs())
                if (t.getName().toLowerCase().contains(query.toLowerCase()) || t.getCategory().toLowerCase().contains(query.toLowerCase()))
                    addRow(t);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void populateForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        txtName.setText(model.getValueAt(row, 1).toString());
        cmbCategory.setSelectedItem(model.getValueAt(row, 2).toString());
        txtRate.setText(model.getValueAt(row, 3).toString());
    }

    private void addTariff() {
        String name = txtName.getText().trim(), rateText = txtRate.getText().trim();
        if (name.isEmpty() || rateText.isEmpty()) { JOptionPane.showMessageDialog(this, "Name and Rate are required."); return; }
        try {
            double rate = Double.parseDouble(rateText);
            if (rate <= 0) { JOptionPane.showMessageDialog(this, "Rate must be greater than zero."); return; }
            Tariff t = new Tariff();
            t.setName(name); t.setCategory(cmbCategory.getSelectedItem().toString());
            t.setRatePerUnit(rate); t.setEffectiveDate(new Date());
            RMIClientConnector.getService().addTariff(t);
            loadTariffs(); clearForm();
            JOptionPane.showMessageDialog(this, "Tariff added successfully!");
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Enter a valid number for rate.");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error adding tariff!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void updateTariff() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a tariff first!"); return; }
        String name = txtName.getText().trim(), rateText = txtRate.getText().trim();
        if (name.isEmpty() || rateText.isEmpty()) { JOptionPane.showMessageDialog(this, "Name and Rate are required."); return; }
        try {
            double rate = Double.parseDouble(rateText);
            if (rate <= 0) { JOptionPane.showMessageDialog(this, "Rate must be greater than zero."); return; }
            Long id = Long.valueOf(model.getValueAt(row, 0).toString());
            Tariff t = RMIClientConnector.getService().getTariffById(id);
            t.setName(name); t.setCategory(cmbCategory.getSelectedItem().toString()); t.setRatePerUnit(rate);
            RMIClientConnector.getService().updateTariff(t);
            loadTariffs();
            JOptionPane.showMessageDialog(this, "Tariff updated successfully!");
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Enter a valid number for rate.");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error updating tariff!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void deleteTariff() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a tariff first!"); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this tariff?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            RMIClientConnector.getService().deleteTariff(Long.valueOf(model.getValueAt(row, 0).toString()));
            loadTariffs(); clearForm();
            JOptionPane.showMessageDialog(this, "Tariff deleted successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error deleting tariff!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void clearForm() { txtName.setText(""); txtRate.setText(""); cmbCategory.setSelectedIndex(0); }
}
