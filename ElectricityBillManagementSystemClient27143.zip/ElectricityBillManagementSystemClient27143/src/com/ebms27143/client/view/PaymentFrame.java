package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Bill;
import com.ebms27143.entity.Payment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Date;
import java.util.UUID;

public class PaymentFrame extends JFrame {

    private final Long billId;
    private final double totalDue;
    private JTextField txtAmount, txtRef;
    private JComboBox<String> cmbMethod;

    public PaymentFrame(Long billId, double totalDue) {
        this.billId = billId;
        this.totalDue = totalDue;

        setTitle("Record Payment — Bill #" + billId);
        setSize(460, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("P", "Record Payment", "Bill #" + billId + "  —  Process customer payment"), BorderLayout.NORTH);

        // ── FORM CARD ──
        JPanel card = UITheme.makeCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(8, 10, 8, 10);
        g.fill = GridBagConstraints.HORIZONTAL;

        // Bill ID info row
        g.gridx = 0; g.gridy = 0; card.add(UITheme.fieldLabel("Bill ID:"), g);
        g.gridx = 1;
        JLabel lblBillId = new JLabel(String.valueOf(billId));
        lblBillId.setFont(new Font("Arial", Font.BOLD, 13));
        lblBillId.setForeground(UITheme.NAVY);
        card.add(lblBillId, g);

        // Total due info row
        g.gridx = 0; g.gridy = 1; card.add(UITheme.fieldLabel("Total Due (RWF):"), g);
        g.gridx = 1;
        JLabel lblDue = new JLabel(String.format("%.2f", totalDue));
        lblDue.setFont(new Font("Arial", Font.BOLD, 14));
        lblDue.setForeground(UITheme.RED);
        card.add(lblDue, g);

        // Separator
        g.gridx = 0; g.gridy = 2; g.gridwidth = 2;
        JSeparator sep = new JSeparator();
        sep.setForeground(UITheme.BORDER_CLR);
        card.add(sep, g);
        g.gridwidth = 1;

        // Amount paid
        g.gridx = 0; g.gridy = 3; card.add(UITheme.fieldLabel("Amount Paid (RWF):"), g);
        g.gridx = 1;
        txtAmount = UITheme.makeField(15);
        txtAmount.setText(String.format("%.2f", totalDue));
        card.add(txtAmount, g);

        // Method
        g.gridx = 0; g.gridy = 4; card.add(UITheme.fieldLabel("Payment Method:"), g);
        g.gridx = 1;
        cmbMethod = UITheme.makeCombo(new String[]{"CASH", "MOBILE_MONEY", "BANK_TRANSFER"});
        card.add(cmbMethod, g);

        // Transaction ref
        g.gridx = 0; g.gridy = 5; card.add(UITheme.fieldLabel("Transaction Ref:"), g);
        g.gridx = 1;
        txtRef = UITheme.makeField(15);
        txtRef.setText("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
        card.add(txtRef, g);

        JPanel cardWrap = new JPanel(new BorderLayout());
        cardWrap.setBackground(UITheme.BG);
        cardWrap.setBorder(new EmptyBorder(12, 16, 0, 16));
        cardWrap.add(card, BorderLayout.CENTER);
        add(cardWrap, BorderLayout.CENTER);

        // ── BUTTONS ──
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 12));
        btnRow.setBackground(UITheme.BG);
        JButton btnSubmit = UITheme.solidBtn("Submit Payment", UITheme.GREEN, UITheme.WHITE);
        JButton btnCancel = UITheme.outlineBtn("Cancel", UITheme.RED);
        btnRow.add(btnSubmit); btnRow.add(btnCancel);
        add(btnRow, BorderLayout.SOUTH);

        btnSubmit.addActionListener(e -> recordPayment());
        btnCancel.addActionListener(e -> dispose());
    }

    private void recordPayment() {
        String amtText = txtAmount.getText().trim();
        if (amtText.isEmpty()) { JOptionPane.showMessageDialog(this, "Please enter the amount paid."); return; }
        try {
            double amount = Double.parseDouble(amtText);
            if (amount <= 0) { JOptionPane.showMessageDialog(this, "Amount must be greater than zero."); return; }
            if (amount < totalDue) {
                int ok = JOptionPane.showConfirmDialog(this,
                        String.format("Amount (%.2f) is less than total due (%.2f).\nProceed as partial payment?", amount, totalDue),
                        "Partial Payment", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (ok != JOptionPane.YES_OPTION) return;
            }
            Bill bill = new Bill(); bill.setId(billId);
            Payment p = new Payment();
            p.setAmount(amount);
            p.setMethod(cmbMethod.getSelectedItem().toString());
            p.setTransactionRef(txtRef.getText().trim().isEmpty() ? "N/A" : txtRef.getText().trim());
            p.setPaymentDate(new Date());
            p.setBill(bill);
            RMIClientConnector.getService().recordPayment(p);
            JOptionPane.showMessageDialog(this, "Payment recorded successfully!\nBill marked as PAID.", "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Enter a valid amount.");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
