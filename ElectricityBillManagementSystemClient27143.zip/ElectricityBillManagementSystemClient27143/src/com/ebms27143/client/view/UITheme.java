package com.ebms27143.client.view;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class UITheme {

    // ── Palette ──────────────────────────────────────────────────────────
    public static final Color NAVY       = new Color(10, 35, 81);
    public static final Color NAVY_DARK  = new Color(4, 14, 40);
    public static final Color NAVY_LIGHT = new Color(18, 55, 120);
    public static final Color BLUE       = new Color(21, 101, 192);
    public static final Color LIGHT_BLUE = new Color(235, 245, 255);
    public static final Color ACCENT     = new Color(255, 193, 7);
    public static final Color WHITE      = Color.WHITE;
    public static final Color BG         = new Color(241, 244, 249);
    public static final Color TEXT_DARK  = new Color(22, 28, 36);
    public static final Color TEXT_GRAY  = new Color(107, 114, 128);
    public static final Color BORDER_CLR = new Color(209, 219, 229);
    public static final Color GREEN      = new Color(22, 101, 52);
    public static final Color GREEN_BG   = new Color(220, 252, 231);
    public static final Color RED        = new Color(153, 27, 27);
    public static final Color RED_BG     = new Color(254, 226, 226);
    public static final Color AMBER      = new Color(120, 53, 15);
    public static final Color AMBER_BG   = new Color(254, 243, 199);
    public static final Color ROW_ALT    = new Color(248, 250, 252);
    public static final Color TEAL       = new Color(13, 148, 136);
    public static final Color PURPLE     = new Color(109, 40, 217);
    public static final Color ORANGE     = new Color(194, 65, 12);

    // ── App window icon (drawn bolt in circle) ────────────────────────────
    public static BufferedImage createAppIcon(int size) {
        BufferedImage img = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = img.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        // Circle background
        g2.setColor(NAVY);
        g2.fillOval(0, 0, size, size);
        // Bolt polygon
        g2.setColor(ACCENT);
        drawBolt(g2, size);
        g2.dispose();
        return img;
    }

    // ── Inline bolt icon JPanel (for brand/logo areas) ────────────────────
    public static JPanel makeBoltIcon(int size, Color bgColor, Color boltColor) {
        return new JPanel() {
            {
                setOpaque(false);
                setPreferredSize(new Dimension(size, size));
                setMinimumSize(new Dimension(size, size));
                setMaximumSize(new Dimension(size, size));
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bgColor);
                g2.fillOval(0, 0, size, size);
                g2.setColor(boltColor);
                drawBolt(g2, size);
                g2.dispose();
            }
        };
    }

    // Draws a lightning bolt scaled to [0..size]
    private static void drawBolt(Graphics2D g2, int s) {
        int[] bx = {s*56/100, s*78/100, s*54/100, s*44/100, s*22/100, s*46/100};
        int[] by = {s* 6/100, s*50/100, s*50/100, s*94/100, s*50/100, s*50/100};
        g2.fillPolygon(bx, by, 6);
    }

    // ── Letter-icon JPanel (rounded square with letter) ───────────────────
    public static JPanel makeLetterIcon(String letter, int size, Color bg, Color fg) {
        return new JPanel() {
            {
                setOpaque(false);
                setPreferredSize(new Dimension(size, size));
                setMinimumSize(new Dimension(size, size));
                setMaximumSize(new Dimension(size, size));
            }
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fillRoundRect(0, 0, size, size, size / 3, size / 3);
                g2.setColor(fg);
                int fontSize = size * 45 / 100;
                g2.setFont(new Font("Segoe UI", Font.BOLD, fontSize));
                FontMetrics fm = g2.getFontMetrics();
                int tx = (size - fm.stringWidth(letter)) / 2;
                int ty = (size + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(letter, tx, ty);
                g2.dispose();
            }
        };
    }

    // ── Header bar ────────────────────────────────────────────────────────
    public static JPanel makeHeader(String iconLetter, String title, String subtitle) {
        JPanel header = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, NAVY_DARK, getWidth(), 0, new Color(12, 45, 110)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(ACCENT);
                g2.fillRect(0, getHeight() - 3, 80, 3);
                g2.dispose();
            }
        };
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(16, 24, 16, 24));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridheight = 2;
        gbc.insets = new Insets(0, 0, 0, 16);
        gbc.anchor = GridBagConstraints.CENTER;

        // Icon: letter in a semi-transparent rounded square
        Color iconBg = new Color(255, 255, 255, 28);
        JPanel icon = makeLetterIcon(iconLetter, 46, iconBg, ACCENT);
        header.add(icon, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.gridheight = 1;
        gbc.insets = new Insets(0, 0, 3, 0);
        gbc.anchor = GridBagConstraints.WEST;
        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 17));
        lblTitle.setForeground(WHITE);
        header.add(lblTitle, gbc);

        gbc.gridy = 1;
        gbc.insets = new Insets(0, 0, 0, 0);
        JLabel lblSub = new JLabel(subtitle);
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblSub.setForeground(new Color(155, 190, 225));
        header.add(lblSub, gbc);

        return header;
    }

    // ── Section label ─────────────────────────────────────────────────────
    public static JLabel sectionLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(NAVY);
        lbl.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 3, 0, 0, BLUE),
                new EmptyBorder(2, 9, 2, 0)));
        return lbl;
    }

    // ── Text field ────────────────────────────────────────────────────────
    public static JTextField makeField(int cols) {
        JTextField f = new JTextField(cols);
        styleField(f);
        return f;
    }

    public static JPasswordField makePasswordField(int cols) {
        JPasswordField f = new JPasswordField(cols);
        styleField(f);
        return f;
    }

    public static void styleField(JTextField f) {
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBackground(new Color(248, 250, 253));
        f.setForeground(TEXT_DARK);
        f.setCaretColor(NAVY);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_CLR, 1),
                new EmptyBorder(7, 12, 7, 12)));
    }

    // ── Combo box ─────────────────────────────────────────────────────────
    public static <T> JComboBox<T> makeCombo(T[] items) {
        JComboBox<T> cb = new JComboBox<>(items);
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(new Color(248, 250, 253));
        return cb;
    }

    // ── Solid button ──────────────────────────────────────────────────────
    public static JButton solidBtn(String text, Color bg, Color fg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(8, 20, 8, 20));
        Color hover = bg.darker();
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(hover); btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(bg);    btn.repaint(); }
        });
        return btn;
    }

    // ── Outline button ────────────────────────────────────────────────────
    public static JButton outlineBtn(String text, Color color) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
            @Override
            protected void paintBorder(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(color);
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1, 1, getWidth() - 2, getHeight() - 2, 8, 8);
                g2.dispose();
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(WHITE);
        btn.setForeground(color);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(new EmptyBorder(7, 20, 7, 20));
        Color hoverBg = new Color(
                Math.min(255, color.getRed()   + 200),
                Math.min(255, color.getGreen() + 200),
                Math.min(255, color.getBlue()  + 200));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(hoverBg); btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(WHITE);   btn.repaint(); }
        });
        return btn;
    }

    // ── Table styling ─────────────────────────────────────────────────────
    public static void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(33);
        table.setGridColor(new Color(232, 238, 244));
        table.setSelectionBackground(new Color(219, 234, 254));
        table.setSelectionForeground(NAVY);
        table.setBackground(WHITE);
        table.setForeground(TEXT_DARK);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFocusable(false);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 12));
        header.setBackground(new Color(28, 54, 130));
        header.setForeground(WHITE);
        header.setOpaque(true);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(header.getWidth(), 38));
        header.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                JLabel lbl = (JLabel) super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                lbl.setBackground(new Color(28, 54, 130));
                lbl.setForeground(WHITE);
                lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
                lbl.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(18, 38, 100)),
                        new EmptyBorder(0, 12, 0, 12)));
                lbl.setOpaque(true);
                return lbl;
            }
        });

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                setFont(new Font("Segoe UI", Font.PLAIN, 13));
                setBorder(new EmptyBorder(0, 12, 0, 12));
                if (sel) {
                    setBackground(new Color(219, 234, 254));
                    setForeground(NAVY);
                } else {
                    setBackground(row % 2 == 0 ? WHITE : ROW_ALT);
                    setForeground(TEXT_DARK);
                }
                return this;
            }
        });
    }

    // ── Search bar ────────────────────────────────────────────────────────
    public static JPanel makeSearchBar(JTextField searchField, JButton searchBtn) {
        JPanel panel = new JPanel(new BorderLayout(8, 0));
        panel.setBackground(WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_CLR),
                new EmptyBorder(10, 16, 10, 16)));
        JLabel lbl = new JLabel("Search: ");
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lbl.setForeground(TEXT_GRAY);
        panel.add(lbl, BorderLayout.WEST);
        panel.add(searchField, BorderLayout.CENTER);
        panel.add(searchBtn, BorderLayout.EAST);
        return panel;
    }

    // ── Form card ─────────────────────────────────────────────────────────
    public static JPanel makeCard() {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 10));
                g2.fillRoundRect(2, 3, getWidth() - 2, getHeight() - 2, 10, 10);
                g2.setColor(WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 3, 10, 10);
                g2.setColor(BORDER_CLR);
                g2.setStroke(new BasicStroke(0.8f));
                g2.drawRoundRect(0, 0, getWidth() - 3, getHeight() - 4, 10, 10);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(16, 18, 16, 18));
        return card;
    }

    // ── Dashboard stat card ───────────────────────────────────────────────
    public static JPanel makeStatCard(String letter, String title, String value, Color accentColor) {
        JPanel card = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 10));
                g2.fillRoundRect(2, 3, getWidth() - 2, getHeight() - 2, 10, 10);
                g2.setColor(WHITE);
                g2.fillRoundRect(0, 0, getWidth() - 2, getHeight() - 3, 10, 10);
                // bottom accent stripe
                g2.setColor(accentColor);
                g2.fillRoundRect(0, getHeight() - 5, getWidth() - 2, 5, 0, 0);
                g2.dispose();
            }
        };
        card.setOpaque(false);
        card.setLayout(new BorderLayout(0, 0));
        card.setBorder(new EmptyBorder(14, 18, 16, 14));

        // Icon circle
        JPanel iconCircle = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 22));
                g2.fillOval(0, 0, getWidth(), getHeight());
                // letter
                g2.setColor(accentColor);
                g2.setFont(new Font("Segoe UI", Font.BOLD, 16));
                FontMetrics fm = g2.getFontMetrics();
                int tx = (getWidth() - fm.stringWidth(letter)) / 2;
                int ty = (getHeight() + fm.getAscent() - fm.getDescent()) / 2;
                g2.drawString(letter, tx, ty);
                g2.dispose();
            }
        };
        iconCircle.setOpaque(false);
        iconCircle.setPreferredSize(new Dimension(44, 44));
        card.add(iconCircle, BorderLayout.WEST);

        JPanel textPanel = new JPanel();
        textPanel.setOpaque(false);
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setBorder(new EmptyBorder(2, 12, 0, 0));

        JLabel lblValue = new JLabel(value);
        lblValue.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblValue.setForeground(NAVY);
        textPanel.add(lblValue);

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblTitle.setForeground(TEXT_GRAY);
        textPanel.add(lblTitle);

        card.add(textPanel, BorderLayout.CENTER);
        return card;
    }

    // ── Status / footer bar ───────────────────────────────────────────────
    public static JPanel makeStatusBar(String text) {
        JPanel bar = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, NAVY_DARK, getWidth(), 0, NAVY));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        bar.setOpaque(false);
        bar.setBorder(new EmptyBorder(5, 16, 5, 16));
        JLabel lblLeft = new JLabel(text);
        lblLeft.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblLeft.setForeground(new Color(155, 185, 215));
        bar.add(lblLeft, BorderLayout.WEST);
        JLabel lblRight = new JLabel("EBMS  v2.0");
        lblRight.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblRight.setForeground(new Color(120, 155, 190));
        bar.add(lblRight, BorderLayout.EAST);
        return bar;
    }

    // ── Field label ───────────────────────────────────────────────────────
    public static JLabel fieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(55, 65, 81));
        return lbl;
    }
}
