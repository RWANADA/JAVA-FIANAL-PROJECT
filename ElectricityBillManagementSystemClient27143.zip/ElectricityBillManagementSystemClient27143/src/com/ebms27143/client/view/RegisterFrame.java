package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class RegisterFrame extends JFrame {

    private JTextField     txtUsername;
    private JPasswordField txtPassword;
    private JPasswordField txtConfirmPassword;
    private JTextField     txtEmail;
    private JComboBox<String> cmbRole;

    private static final Color NAVY      = UITheme.NAVY;
    private static final Color NAVY_DARK = UITheme.NAVY_DARK;
    private static final Color BLUE      = UITheme.BLUE;
    private static final Color ACCENT    = UITheme.ACCENT;
    private static final Color WHITE     = UITheme.WHITE;
    private static final Color BG        = UITheme.BG;
    private static final Color TEXT_DARK = UITheme.TEXT_DARK;
    private static final Color TEXT_GRAY = UITheme.TEXT_GRAY;
    private static final Color BORDER    = UITheme.BORDER_CLR;

    public RegisterFrame() {
        setTitle("EBMS — Create Account");
        setSize(820, 580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setIconImage(UITheme.createAppIcon(64));

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        setContentPane(root);

        // ── LEFT: brand strip ───────────────────────────────────────────
        JPanel left = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, NAVY_DARK, 0, getHeight(), new Color(8, 38, 100)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 6));
                g2.fillOval(-40, getHeight() / 2, 200, 200);
                g2.setColor(new Color(255, 255, 255, 5));
                g2.fillOval(getWidth() - 50, -40, 180, 180);
                g2.setColor(new Color(34, 197, 94, 80));
                g2.fillRect(getWidth() - 3, 0, 3, getHeight());
                g2.dispose();
            }
        };
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(300, 580));

        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0; lc.gridy = 0; lc.insets = new Insets(0, 0, 8, 0);

        JPanel bolt = UITheme.makeBoltIcon(56, new Color(255, 255, 255, 22), ACCENT);
        left.add(bolt, lc);

        lc.gridy = 1; lc.insets = new Insets(0, 0, 6, 0);
        JLabel lblApp = new JLabel("Join EBMS");
        lblApp.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblApp.setForeground(WHITE);
        left.add(lblApp, lc);

        lc.gridy = 2; lc.insets = new Insets(0, 24, 0, 24);
        JLabel lblDesc = new JLabel(
                "<html><center>Create your administrator or<br>staff account to access<br>the billing system.</center></html>");
        lblDesc.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblDesc.setForeground(new Color(155, 195, 235));
        lblDesc.setHorizontalAlignment(SwingConstants.CENTER);
        left.add(lblDesc, lc);

        lc.gridy = 3; lc.insets = new Insets(36, 0, 0, 0);
        JLabel lblSub = new JLabel("AUCA INSY 7312  ·  ID 27143");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        lblSub.setForeground(new Color(110, 155, 200));
        left.add(lblSub, lc);

        root.add(left, BorderLayout.WEST);

        // ── RIGHT: form card ────────────────────────────────────────────
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(BG);

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                new EmptyBorder(30, 38, 30, 38)));
        card.setPreferredSize(new Dimension(400, 500));

        JLabel lblTitle = new JLabel("Create New Account");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitle.setForeground(NAVY);
        lblTitle.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblTitle);

        JLabel lblHint = new JLabel("Fill in your details to register");
        lblHint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblHint.setForeground(TEXT_GRAY);
        lblHint.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblHint);
        card.add(Box.createVerticalStrut(22));

        card.add(lbl("Username"));   card.add(Box.createVerticalStrut(5));
        txtUsername = field();        card.add(txtUsername);
        card.add(Box.createVerticalStrut(12));

        card.add(lbl("Email Address")); card.add(Box.createVerticalStrut(5));
        txtEmail = field();              card.add(txtEmail);
        card.add(Box.createVerticalStrut(12));

        card.add(lbl("Role")); card.add(Box.createVerticalStrut(5));
        cmbRole = new JComboBox<>(new String[]{"STAFF", "ADMIN"});
        cmbRole.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbRole.setBackground(new Color(248, 250, 253));
        cmbRole.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        cmbRole.setAlignmentX(LEFT_ALIGNMENT);
        card.add(cmbRole);
        card.add(Box.createVerticalStrut(12));

        card.add(lbl("Password")); card.add(Box.createVerticalStrut(5));
        txtPassword = new JPasswordField();
        styleF(txtPassword);          card.add(txtPassword);
        card.add(Box.createVerticalStrut(12));

        card.add(lbl("Confirm Password")); card.add(Box.createVerticalStrut(5));
        txtConfirmPassword = new JPasswordField();
        styleF(txtConfirmPassword);        card.add(txtConfirmPassword);
        card.add(Box.createVerticalStrut(22));

        JButton btnRegister = roundBtn("Create Account", UITheme.GREEN, WHITE);
        card.add(btnRegister);
        card.add(Box.createVerticalStrut(10));

        JButton btnBack = roundBtn("Back to Login", WHITE, BLUE);
        btnBack.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BLUE, 1),
                new EmptyBorder(10, 20, 10, 20)));
        btnBack.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnBack.setBackground(UITheme.LIGHT_BLUE); btnBack.repaint(); }
            public void mouseExited(MouseEvent e)  { btnBack.setBackground(WHITE);              btnBack.repaint(); }
        });
        card.add(btnBack);

        right.add(card);
        root.add(right, BorderLayout.CENTER);

        btnRegister.addActionListener(e -> register());
        btnBack.addActionListener(e -> dispose());
        getRootPane().setDefaultButton(btnRegister);
    }

    private JLabel lbl(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(new Color(55, 65, 81));
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField field() {
        JTextField f = new JTextField();
        styleF(f);
        return f;
    }

    private void styleF(JTextField f) {
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBackground(new Color(248, 250, 253));
        f.setForeground(TEXT_DARK);
        f.setCaretColor(NAVY);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1),
                new EmptyBorder(7, 12, 7, 12)));
        f.setAlignmentX(LEFT_ALIGNMENT);
    }

    private JButton roundBtn(String text, Color bg, Color fg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        Color hover = bg.equals(WHITE) ? UITheme.LIGHT_BLUE : bg.darker();
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(hover); btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(bg);    btn.repaint(); }
        });
        return btn;
    }

    private void register() {
        String username        = txtUsername.getText().trim();
        String email           = txtEmail.getText().trim();
        String password        = new String(txtPassword.getPassword()).trim();
        String confirmPassword = new String(txtConfirmPassword.getPassword()).trim();
        String role            = cmbRole.getSelectedItem().toString();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (username.length() < 3) {
            JOptionPane.showMessageDialog(this, "Username must be at least 3 characters!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!email.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password must be at least 4 characters!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            User user = new User();
            user.setUsername(username);
            user.setEmail(email);
            user.setRole(role);
            user.setPasswordHash(password);
            RMIClientConnector.getService().registerUser(user);
            JOptionPane.showMessageDialog(this,
                    "Account created successfully! You can now login.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating account: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
