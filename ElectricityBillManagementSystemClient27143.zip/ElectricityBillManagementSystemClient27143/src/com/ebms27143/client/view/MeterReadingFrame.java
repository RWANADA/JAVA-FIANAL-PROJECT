package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Meter;
import com.ebms27143.entity.MeterReading;
import com.ebms27143.entity.Tariff;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;

public class MeterReadingFrame extends JFrame {

    private JTextField txtPrev, txtCurrent;
    private JComboBox<Tariff> cmbTariff;
    private JComboBox<Meter> cmbMeter;

    public MeterReadingFrame() {
        setTitle("Meter Reading Entry");
        setSize(480, 420);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("R", "Meter Reading Entry", "Enter monthly meter readings and generate bills"), BorderLayout.NORTH);

        // ── FORM CARD ──
        JPanel card = UITheme.makeCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(9, 10, 9, 10);
        g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;

        cmbMeter = new JComboBox<>();
        cmbMeter.setFont(new Font("Arial", Font.PLAIN, 13));
        cmbMeter.setBackground(UITheme.LIGHT_BLUE);

        cmbTariff = new JComboBox<>();
        cmbTariff.setFont(new Font("Arial", Font.PLAIN, 13));
        cmbTariff.setBackground(UITheme.LIGHT_BLUE);

        txtPrev    = UITheme.makeField(15);
        txtCurrent = UITheme.makeField(15);

        addRow(card, g, 0, "Meter:", cmbMeter);
        addRow(card, g, 1, "Previous Units:", txtPrev);
        addRow(card, g, 2, "Current Units:", txtCurrent);
        addRow(card, g, 3, "Tariff:", cmbTariff);

        // Consumption preview label
        g.gridx = 0; g.gridy = 4; g.gridwidth = 2;
        JLabel lblHint = new JLabel("Enter readings above, then click Generate Bill.");
        lblHint.setFont(new Font("Arial", Font.ITALIC, 11));
        lblHint.setForeground(UITheme.TEXT_GRAY);
        card.add(lblHint, g);

        JPanel cardWrap = new JPanel(new BorderLayout());
        cardWrap.setBackground(UITheme.BG);
        cardWrap.setBorder(new EmptyBorder(12, 16, 0, 16));
        cardWrap.add(UITheme.sectionLabel("Reading Details"), BorderLayout.NORTH);
        cardWrap.add(card, BorderLayout.CENTER);
        add(cardWrap, BorderLayout.CENTER);

        // ── BUTTONS ──
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 14, 12));
        btnRow.setBackground(UITheme.BG);
        JButton btnGenerate = UITheme.solidBtn("Generate Bill", UITheme.NAVY, UITheme.WHITE);
        JButton btnClear    = UITheme.outlineBtn("Clear", UITheme.RED);
        btnRow.add(btnGenerate); btnRow.add(btnClear);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(btnRow, BorderLayout.CENTER);
        add(southWrapper, BorderLayout.SOUTH);

        btnGenerate.addActionListener(e -> generateBill());
        btnClear.addActionListener(e -> { txtPrev.setText(""); txtCurrent.setText(""); });

        loadMeters();
        loadTariffs();
    }

    private void addRow(JPanel p, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridx = 0; g.gridy = row; g.gridwidth = 1; g.weightx = 0;
        p.add(UITheme.fieldLabel(label), g);
        g.gridx = 1; g.weightx = 1.0;
        p.add(field, g);
    }

    private void loadMeters() {
        try {
            List<Meter> meters = RMIClientConnector.getService().getAllMeters();
            cmbMeter.removeAllItems();
            for (Meter m : meters) cmbMeter.addItem(m);
            if (meters.isEmpty())
                JOptionPane.showMessageDialog(this, "No meters found. Please add a meter first.", "No Meters", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Failed to load meters: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void loadTariffs() {
        try {
            List<Tariff> tariffs = RMIClientConnector.getService().getAllTariffs();
            cmbTariff.removeAllItems();
            for (Tariff t : tariffs) cmbTariff.addItem(t);
            if (tariffs.isEmpty())
                JOptionPane.showMessageDialog(this, "No tariffs found. Please add a tariff first.", "No Tariffs", JOptionPane.WARNING_MESSAGE);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Failed to load tariffs: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void generateBill() {
        Meter meter = (Meter) cmbMeter.getSelectedItem();
        Tariff tariff = (Tariff) cmbTariff.getSelectedItem();
        if (meter == null)  { JOptionPane.showMessageDialog(this, "No meter available. Please add a meter first."); return; }
        if (tariff == null) { JOptionPane.showMessageDialog(this, "No tariff available. Please add a tariff first."); return; }

        String prevText = txtPrev.getText().trim(), curText = txtCurrent.getText().trim();
        if (prevText.isEmpty() || curText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Previous and Current units are required!", "Validation", JOptionPane.WARNING_MESSAGE); return;
        }
        try {
            double prev = Double.parseDouble(prevText), cur = Double.parseDouble(curText);
            if (prev < 0 || cur < 0) { JOptionPane.showMessageDialog(this, "Units cannot be negative!", "Validation", JOptionPane.WARNING_MESSAGE); return; }
            if (cur < prev) { JOptionPane.showMessageDialog(this, "Current units cannot be less than previous units."); return; }

            MeterReading reading = new MeterReading();
            reading.setPreviousUnits(prev); reading.setCurrentUnits(cur);
            reading.setReadingDate(new java.util.Date()); reading.setMeter(meter);

            RMIClientConnector.getService().addMeterReadingAndGenerateBill(reading, tariff.getId());
            JOptionPane.showMessageDialog(this, "Bill generated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            txtPrev.setText(""); txtCurrent.setText("");
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Please enter valid numbers for units.");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Bill generation failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
