package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LoginFrame extends JFrame {

    private JTextField     txtUsername;
    private JPasswordField txtPassword;

    private static final Color NAVY      = UITheme.NAVY;
    private static final Color NAVY_DARK = UITheme.NAVY_DARK;
    private static final Color BLUE      = UITheme.BLUE;
    private static final Color ACCENT    = UITheme.ACCENT;
    private static final Color WHITE     = UITheme.WHITE;
    private static final Color BG        = UITheme.BG;
    private static final Color TEXT_DARK = UITheme.TEXT_DARK;
    private static final Color TEXT_GRAY = UITheme.TEXT_GRAY;
    private static final Color BORDER_C  = UITheme.BORDER_CLR;

    public LoginFrame() {
        setTitle("EBMS — Electricity Bill Management System");
        setSize(860, 560);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
        setIconImage(UITheme.createAppIcon(64));

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        setContentPane(root);

        // ── LEFT: brand panel ──────────────────────────────────────────
        JPanel left = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setPaint(new GradientPaint(0, 0, NAVY_DARK, 0, getHeight(), new Color(10, 45, 115)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                // decorative circles
                g2.setColor(new Color(255, 255, 255, 7));
                g2.fillOval(-50, -50, 250, 250);
                g2.setColor(new Color(255, 255, 255, 5));
                g2.fillOval(getWidth() - 130, getHeight() - 180, 250, 250);
                // accent bottom bar
                g2.setColor(ACCENT);
                g2.fillRect(0, getHeight() - 4, getWidth(), 4);
                g2.dispose();
            }
        };
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(340, 560));

        GridBagConstraints lc = new GridBagConstraints();
        lc.gridx = 0; lc.gridy = 0; lc.insets = new Insets(0, 0, 10, 0);

        // Custom drawn bolt icon
        JPanel bolt = UITheme.makeBoltIcon(64, new Color(255, 255, 255, 25), ACCENT);
        left.add(bolt, lc);

        lc.gridy = 1; lc.insets = new Insets(0, 0, 6, 0);
        JLabel lblApp = new JLabel("EBMS");
        lblApp.setFont(new Font("Segoe UI", Font.BOLD, 36));
        lblApp.setForeground(WHITE);
        left.add(lblApp, lc);

        lc.gridy = 2; lc.insets = new Insets(0, 24, 0, 24);
        JLabel lblFull = new JLabel(
                "<html><div style='text-align:center;'>Electricity Bill<br>Management System</div></html>");
        lblFull.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        lblFull.setForeground(new Color(165, 200, 235));
        lblFull.setHorizontalAlignment(SwingConstants.CENTER);
        left.add(lblFull, lc);

        lc.gridy = 3; lc.insets = new Insets(28, 28, 0, 28);
        JPanel tags = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 4));
        tags.setOpaque(false);
        for (String t : new String[]{"Billing", "Meters", "Reports", "Payments"}) {
            JLabel tag = new JLabel(t);
            tag.setFont(new Font("Segoe UI", Font.PLAIN, 10));
            tag.setForeground(new Color(140, 180, 220));
            tag.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(255, 255, 255, 28), 1),
                    new EmptyBorder(3, 8, 3, 8)));
            tags.add(tag);
        }
        left.add(tags, lc);

        lc.gridy = 4; lc.insets = new Insets(36, 20, 0, 20);
        JLabel footer = new JLabel(
                "<html><center>AUCA INSY 7312<br>"
                + "<span style='color:#8BAABB'>Iradukunda Kubana Christian &middot; 27143</span>"
                + "</center></html>");
        footer.setFont(new Font("Segoe UI", Font.PLAIN, 10));
        footer.setForeground(new Color(120, 160, 200));
        footer.setHorizontalAlignment(SwingConstants.CENTER);
        left.add(footer, lc);

        root.add(left, BorderLayout.WEST);

        // ── RIGHT: form card ───────────────────────────────────────────
        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(BG);

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_C, 1),
                new EmptyBorder(38, 42, 38, 42)));
        card.setPreferredSize(new Dimension(386, 440));

        JLabel lblWelcome = new JLabel("Welcome Back");
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 23));
        lblWelcome.setForeground(NAVY);
        lblWelcome.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblWelcome);

        JLabel lblHint = new JLabel("Sign in to continue to your account");
        lblHint.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblHint.setForeground(TEXT_GRAY);
        lblHint.setAlignmentX(LEFT_ALIGNMENT);
        card.add(lblHint);
        card.add(Box.createVerticalStrut(30));

        card.add(inputLabel("Username"));
        card.add(Box.createVerticalStrut(6));
        txtUsername = new JTextField();
        styleField(txtUsername);
        card.add(txtUsername);
        card.add(Box.createVerticalStrut(16));

        card.add(inputLabel("Password"));
        card.add(Box.createVerticalStrut(6));
        txtPassword = new JPasswordField();
        styleField(txtPassword);
        card.add(txtPassword);
        card.add(Box.createVerticalStrut(28));

        JButton btnLogin = primaryBtn("Sign In", NAVY, WHITE);
        card.add(btnLogin);
        card.add(Box.createVerticalStrut(14));

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(220, 228, 240));
        sep.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sep.setAlignmentX(LEFT_ALIGNMENT);
        card.add(sep);
        card.add(Box.createVerticalStrut(14));

        JLabel lblOr = new JLabel("Don't have an account?");
        lblOr.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lblOr.setForeground(TEXT_GRAY);
        lblOr.setAlignmentX(CENTER_ALIGNMENT);
        card.add(lblOr);
        card.add(Box.createVerticalStrut(8));

        JButton btnCreate = primaryBtn("Create Account", WHITE, BLUE);
        btnCreate.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BLUE, 1),
                new EmptyBorder(10, 20, 10, 20)));
        btnCreate.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btnCreate.setBackground(UITheme.LIGHT_BLUE); btnCreate.repaint(); }
            public void mouseExited(MouseEvent e)  { btnCreate.setBackground(WHITE);              btnCreate.repaint(); }
        });
        card.add(btnCreate);

        right.add(card);
        root.add(right, BorderLayout.CENTER);

        btnLogin.addActionListener(e -> login());
        btnCreate.addActionListener(e -> new RegisterFrame().setVisible(true));
        getRootPane().setDefaultButton(btnLogin);
    }

    private JLabel inputLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(55, 65, 81));
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        return lbl;
    }

    private void styleField(JTextField f) {
        f.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        f.setBackground(new Color(248, 250, 253));
        f.setForeground(TEXT_DARK);
        f.setCaretColor(NAVY);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER_C, 1),
                new EmptyBorder(8, 12, 8, 12)));
        f.setAlignmentX(LEFT_ALIGNMENT);
    }

    private JButton primaryBtn(String text, Color bg, Color fg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getBackground());
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(fg);
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setOpaque(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btn.setAlignmentX(CENTER_ALIGNMENT);
        if (bg.equals(NAVY)) {
            btn.addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { btn.setBackground(BLUE); btn.repaint(); }
                public void mouseExited(MouseEvent e)  { btn.setBackground(NAVY); btn.repaint(); }
            });
        }
        return btn;
    }

    private void login() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Username and password are required!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (username.length() < 3) {
            JOptionPane.showMessageDialog(this, "Username must be at least 3 characters!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (password.length() < 4) {
            JOptionPane.showMessageDialog(this, "Password must be at least 4 characters!", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            User user = RMIClientConnector.getService().authenticateUser(username, password);
            if (user != null) {
                showOtpDialog(user);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Server connection failed!", "Connection Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showOtpDialog(User user) {
        String otpInput = JOptionPane.showInputDialog(this, "Enter OTP sent to your email:");
        if (otpInput == null) return;
        try {
            boolean valid = RMIClientConnector.getService().verifyOtp(user.getId(), otpInput);
            if (valid) {
                JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                new DashboardFrame(user).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid or expired OTP!", "OTP Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
        new LoginFrame().setVisible(true);
    }
}
