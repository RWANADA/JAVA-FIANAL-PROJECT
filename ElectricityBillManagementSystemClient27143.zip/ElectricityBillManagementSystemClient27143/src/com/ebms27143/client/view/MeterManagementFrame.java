package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Customer;
import com.ebms27143.entity.Meter;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.Date;
import java.util.List;

public class MeterManagementFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtMeterNumber, txtSearch;
    private JComboBox<String> cmbType, cmbStatus;
    private JComboBox<Customer> cmbCustomer;

    public MeterManagementFrame() {
        setTitle("Meter Management");
        setSize(980, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("M", "Meter Management", "Register and manage electricity meters"), BorderLayout.NORTH);

        // ── CENTER: search + table ──
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(12, 14, 0, 14));

        txtSearch = UITheme.makeField(20);
        JButton btnSearch = UITheme.solidBtn("Search", UITheme.BLUE, UITheme.WHITE);
        center.add(UITheme.makeSearchBar(txtSearch, btnSearch), BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Meter Number", "Type", "Status", "Install Date", "Customer"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ── SOUTH: form + buttons ──
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setBackground(UITheme.BG);
        south.setBorder(new EmptyBorder(10, 14, 6, 14));

        JPanel formCard = UITheme.makeCard();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        txtMeterNumber = UITheme.makeField(14);
        cmbType   = UITheme.makeCombo(new String[]{"Residential", "Commercial", "Industrial"});
        cmbStatus = UITheme.makeCombo(new String[]{"ACTIVE", "INACTIVE"});
        cmbCustomer = new JComboBox<>();
        cmbCustomer.setFont(new Font("Arial", Font.PLAIN, 13));
        cmbCustomer.setBackground(UITheme.LIGHT_BLUE);

        g.gridx = 0; g.gridy = 0; formCard.add(UITheme.fieldLabel("Meter Number:"), g);
        g.gridx = 1; formCard.add(txtMeterNumber, g);
        g.gridx = 2; formCard.add(UITheme.fieldLabel("Type:"), g);
        g.gridx = 3; formCard.add(cmbType, g);

        g.gridx = 0; g.gridy = 1; formCard.add(UITheme.fieldLabel("Status:"), g);
        g.gridx = 1; formCard.add(cmbStatus, g);
        g.gridx = 2; formCard.add(UITheme.fieldLabel("Customer:"), g);
        g.gridx = 3; formCard.add(cmbCustomer, g);

        south.add(UITheme.sectionLabel("Meter Details"), BorderLayout.NORTH);
        south.add(formCard, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        btnRow.setBackground(UITheme.BG);
        JButton btnAdd    = UITheme.solidBtn("Add",     UITheme.GREEN, UITheme.WHITE);
        JButton btnUpdate = UITheme.solidBtn("Update",  UITheme.BLUE,  UITheme.WHITE);
        JButton btnDelete = UITheme.solidBtn("Delete",  UITheme.RED,   UITheme.WHITE);
        JButton btnRefresh= UITheme.solidBtn("Refresh", UITheme.NAVY,  UITheme.WHITE);
        btnRow.add(btnAdd); btnRow.add(btnUpdate); btnRow.add(btnDelete); btnRow.add(btnRefresh);
        south.add(btnRow, BorderLayout.SOUTH);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(south, BorderLayout.CENTER);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  Meter Management"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        btnAdd.addActionListener(e -> addMeter());
        btnUpdate.addActionListener(e -> updateMeter());
        btnDelete.addActionListener(e -> deleteMeter());
        btnRefresh.addActionListener(e -> loadMeters());
        btnSearch.addActionListener(e -> searchMeters(txtSearch.getText()));
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) populateForm(); });

        loadCustomers();
        loadMeters();
    }

    private void loadMeters() {
        try {
            model.setRowCount(0);
            for (Meter m : RMIClientConnector.getService().getAllMeters()) addRow(m);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error loading meters!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void addRow(Meter m) {
        String cust = m.getCustomer() != null ? m.getCustomer().getAccountNo() + " - " + m.getCustomer().getName() : "N/A";
        model.addRow(new Object[]{m.getId(), m.getMeterNumber(), m.getType(), m.getStatus(), m.getInstallDate(), cust});
    }

    private void loadCustomers() {
        try {
            cmbCustomer.removeAllItems();
            for (Customer c : RMIClientConnector.getService().getAllCustomers()) cmbCustomer.addItem(c);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void searchMeters(String query) {
        try {
            model.setRowCount(0);
            for (Meter m : RMIClientConnector.getService().getAllMeters())
                if (m.getMeterNumber().toLowerCase().contains(query.toLowerCase())) addRow(m);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void populateForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        txtMeterNumber.setText(model.getValueAt(row, 1).toString());
        cmbType.setSelectedItem(model.getValueAt(row, 2).toString());
        cmbStatus.setSelectedItem(model.getValueAt(row, 3).toString());
    }

    private void addMeter() {
        String num = txtMeterNumber.getText().trim();
        if (num.isEmpty()) { JOptionPane.showMessageDialog(this, "Meter number cannot be empty."); return; }
        Customer cust = (Customer) cmbCustomer.getSelectedItem();
        if (cust == null) { JOptionPane.showMessageDialog(this, "Please select a customer."); return; }
        try {
            Meter m = new Meter();
            m.setMeterNumber(num); m.setType(cmbType.getSelectedItem().toString());
            m.setStatus(cmbStatus.getSelectedItem().toString()); m.setInstallDate(new Date()); m.setCustomer(cust);
            RMIClientConnector.getService().addMeter(m);
            loadMeters();
            JOptionPane.showMessageDialog(this, "Meter added successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error adding meter!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void updateMeter() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a meter first!"); return; }
        String num = txtMeterNumber.getText().trim();
        if (num.isEmpty()) { JOptionPane.showMessageDialog(this, "Meter number cannot be empty."); return; }
        try {
            Long id = Long.valueOf(model.getValueAt(row, 0).toString());
            Meter m = RMIClientConnector.getService().getMeterById(id);
            m.setMeterNumber(num); m.setType(cmbType.getSelectedItem().toString());
            m.setStatus(cmbStatus.getSelectedItem().toString());
            Customer cust = (Customer) cmbCustomer.getSelectedItem();
            if (cust != null) m.setCustomer(cust);
            RMIClientConnector.getService().updateMeter(m);
            loadMeters();
            JOptionPane.showMessageDialog(this, "Meter updated successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error updating meter!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void deleteMeter() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a meter first!"); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this meter?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            RMIClientConnector.getService().deleteMeter(Long.valueOf(model.getValueAt(row, 0).toString()));
            loadMeters();
            JOptionPane.showMessageDialog(this, "Meter deleted successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error deleting meter!", "Error", JOptionPane.ERROR_MESSAGE); }
    }
}
