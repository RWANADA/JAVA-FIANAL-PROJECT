package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Bill;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class BillManagementFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;

    public BillManagementFrame() {
        setTitle("Bill Management");
        setSize(950, 580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("B", "Bill Management", "View, manage and process electricity bills"), BorderLayout.NORTH);

        // ── TABLE ──
        model = new DefaultTableModel(new String[]{"ID", "Issue Date", "Due Date", "Amount (RWF)", "Penalty (RWF)", "Status"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        // Color-code status column
        table.getColumnModel().getColumn(5).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                setBorder(new EmptyBorder(0, 10, 0, 10));
                String status = val != null ? val.toString() : "";
                if (sel) {
                    setBackground(new Color(197, 218, 245));
                    setForeground(UITheme.TEXT_DARK);
                } else {
                    setBackground(row % 2 == 0 ? UITheme.WHITE : UITheme.ROW_ALT);
                    if (status.equals("PAID"))        setForeground(UITheme.GREEN);
                    else if (status.equals("UNPAID")) setForeground(UITheme.RED);
                    else                              setForeground(UITheme.TEXT_DARK);
                }
                setFont(getFont().deriveFont(Font.BOLD));
                return this;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);

        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(12, 14, 0, 14));
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ── BUTTONS ──
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnRow.setBackground(UITheme.BG);
        btnRow.setBorder(new EmptyBorder(6, 14, 6, 14));

        JButton btnRefresh       = UITheme.solidBtn("Refresh",           UITheme.NAVY,  UITheme.WHITE);
        JButton btnAutoPenalty   = UITheme.solidBtn("Auto Penalty (10%)", UITheme.RED,   UITheme.WHITE);
        JButton btnManualPenalty = UITheme.outlineBtn("Manual Penalty",   UITheme.RED);
        JButton btnMarkPaid      = UITheme.solidBtn("Mark as Paid",       UITheme.GREEN, UITheme.WHITE);
        JButton btnPayment       = UITheme.solidBtn("Record Payment",     UITheme.BLUE,  UITheme.WHITE);

        btnRow.add(btnRefresh); btnRow.add(btnAutoPenalty); btnRow.add(btnManualPenalty);
        btnRow.add(btnMarkPaid); btnRow.add(btnPayment);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(btnRow, BorderLayout.CENTER);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  Bill Management"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        btnRefresh.addActionListener(e -> loadBills());
        btnAutoPenalty.addActionListener(e -> applyPenalty());
        btnManualPenalty.addActionListener(e -> applyManualPenalty());
        btnMarkPaid.addActionListener(e -> markAsPaid());
        btnPayment.addActionListener(e -> openPaymentFrame());

        loadBills();
    }

    private void loadBills() {
        try {
            model.setRowCount(0);
            for (Bill b : RMIClientConnector.getService().getAllBills())
                model.addRow(new Object[]{b.getId(), b.getIssueDate(), b.getDueDate(),
                        String.format("%.2f", b.getTotalAmount()), String.format("%.2f", b.getPenalty()), b.getStatus()});
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void applyPenalty() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a bill first!"); return; }
        String status = model.getValueAt(row, 5).toString();
        if (!status.equals("UNPAID")) { JOptionPane.showMessageDialog(this, "Penalty can only be applied to UNPAID bills."); return; }
        try {
            Long id = Long.valueOf(model.getValueAt(row, 0).toString());
            boolean applied = RMIClientConnector.getService().applyPenaltyIfOverdue(id);
            JOptionPane.showMessageDialog(this, applied ? "Penalty applied successfully!" : "Bill is not overdue yet.");
            if (applied) loadBills();
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void applyManualPenalty() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a bill first!"); return; }
        if (model.getValueAt(row, 5).toString().equals("PAID")) { JOptionPane.showMessageDialog(this, "Cannot apply penalty to a PAID bill."); return; }
        String input = JOptionPane.showInputDialog(this, "Enter penalty amount:", "Manual Penalty", JOptionPane.PLAIN_MESSAGE);
        if (input == null || input.trim().isEmpty()) return;
        try {
            double amount = Double.parseDouble(input.trim());
            if (amount < 0) { JOptionPane.showMessageDialog(this, "Amount cannot be negative."); return; }
            RMIClientConnector.getService().applyManualPenalty(Long.valueOf(model.getValueAt(row, 0).toString()), amount);
            JOptionPane.showMessageDialog(this, "Penalty of " + amount + " applied!");
            loadBills();
        } catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Enter a valid number."); }
        catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void markAsPaid() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a bill first!"); return; }
        try {
            RMIClientConnector.getService().markBillAsPaid(Long.valueOf(model.getValueAt(row, 0).toString()));
            loadBills();
            JOptionPane.showMessageDialog(this, "Bill marked as PAID!");
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void openPaymentFrame() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a bill first!"); return; }
        if (model.getValueAt(row, 5).toString().equals("PAID")) { JOptionPane.showMessageDialog(this, "This bill is already PAID."); return; }
        Long billId = Long.valueOf(model.getValueAt(row, 0).toString());
        double total = Double.parseDouble(model.getValueAt(row, 3).toString());
        double penalty = Double.parseDouble(model.getValueAt(row, 4).toString());
        new PaymentFrame(billId, total + penalty).setVisible(true);
    }
}
