package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Bill;
import com.ebms27143.entity.Customer;
import com.ebms27143.entity.Payment;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReportFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JComboBox<String> cmbReportType;
    private JLabel lblCount;

    private static final String[] REPORT_TYPES = {"All Bills", "Overdue Bills", "All Payments", "All Customers"};

    public ReportFrame() {
        setTitle("Reports & Export");
        setSize(980, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("A", "Reports & Export", "Generate and export system reports"), BorderLayout.NORTH);

        // ── CONTROL BAR ──
        JPanel controlBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        controlBar.setBackground(UITheme.WHITE);
        controlBar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, UITheme.BORDER_CLR),
                new EmptyBorder(2, 10, 2, 10)));

        controlBar.add(UITheme.fieldLabel("Report Type:"));
        cmbReportType = UITheme.makeCombo(REPORT_TYPES);
        cmbReportType.setPreferredSize(new Dimension(200, 32));
        controlBar.add(cmbReportType);

        JButton btnGenerate = UITheme.solidBtn("Generate",  UITheme.NAVY,            UITheme.WHITE);
        JButton btnCSV      = UITheme.solidBtn("Export CSV", UITheme.GREEN,           UITheme.WHITE);
        JButton btnPDF      = UITheme.solidBtn("Print PDF",  new Color(120, 40, 200), UITheme.WHITE);
        controlBar.add(btnGenerate); controlBar.add(btnCSV); controlBar.add(btnPDF);

        lblCount = new JLabel("  No data loaded.");
        lblCount.setFont(new Font("Arial", Font.ITALIC, 11));
        lblCount.setForeground(UITheme.TEXT_GRAY);
        controlBar.add(lblCount);

        // ── TABLE ──
        model = new DefaultTableModel();
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);

        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(0, 14, 10, 14));
        center.add(controlBar, BorderLayout.NORTH);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  Reports"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        btnGenerate.addActionListener(e -> { generateReport(); lblCount.setText("  Records: " + model.getRowCount()); });
        btnCSV.addActionListener(e -> exportToCSV());
        btnPDF.addActionListener(e -> exportToPDF());
    }

    private void generateReport() {
        String type = cmbReportType.getSelectedItem().toString();
        try {
            switch (type) {
                case "All Bills":     loadBillsReport(RMIClientConnector.getService().getAllBills()); break;
                case "Overdue Bills": loadBillsReport(RMIClientConnector.getService().getOverdueBills()); break;
                case "All Payments":  loadPaymentsReport(); break;
                case "All Customers": loadCustomersReport(); break;
            }
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void loadBillsReport(List<Bill> bills) {
        model.setColumnIdentifiers(new String[]{"Bill ID", "Issue Date", "Due Date", "Amount (RWF)", "Penalty (RWF)", "Status"});
        model.setRowCount(0);
        for (Bill b : bills)
            model.addRow(new Object[]{b.getId(), b.getIssueDate(), b.getDueDate(),
                    String.format("%.2f", b.getTotalAmount()), String.format("%.2f", b.getPenalty()), b.getStatus()});
    }

    private void loadPaymentsReport() throws Exception {
        model.setColumnIdentifiers(new String[]{"Payment ID", "Bill ID", "Amount (RWF)", "Method", "Transaction Ref", "Date"});
        model.setRowCount(0);
        for (Payment p : RMIClientConnector.getService().getAllPayments())
            model.addRow(new Object[]{p.getId(), p.getBill() != null ? p.getBill().getId() : "N/A",
                    String.format("%.2f", p.getAmount()), p.getMethod(), p.getTransactionRef(), p.getPaymentDate()});
    }

    private void loadCustomersReport() throws Exception {
        model.setColumnIdentifiers(new String[]{"ID", "Account No", "Name", "Phone", "Email", "Address", "Status"});
        model.setRowCount(0);
        for (Customer c : RMIClientConnector.getService().getAllCustomers())
            model.addRow(new Object[]{c.getId(), c.getAccountNo(), c.getName(), c.getPhone(), c.getEmail(), c.getAddress(), c.getStatus()});
    }

    private void exportToCSV() {
        if (model.getRowCount() == 0) { JOptionPane.showMessageDialog(this, "Generate a report first."); return; }
        try {
            JFileChooser fc = new JFileChooser();
            fc.setSelectedFile(new java.io.File(cmbReportType.getSelectedItem().toString().replace(" ", "_") + "_Report.csv"));
            if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
            String path = fc.getSelectedFile().getAbsolutePath();
            if (!path.endsWith(".csv")) path += ".csv";
            java.io.FileWriter w = new java.io.FileWriter(path);
            for (int c = 0; c < model.getColumnCount(); c++) {
                w.write(model.getColumnName(c)); if (c < model.getColumnCount()-1) w.write(",");
            }
            w.write("\n");
            for (int r = 0; r < model.getRowCount(); r++) {
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object v = model.getValueAt(r, c);
                    w.write(v != null ? v.toString().replace(",", ";") : "");
                    if (c < model.getColumnCount()-1) w.write(",");
                }
                w.write("\n");
            }
            w.close();
            JOptionPane.showMessageDialog(this, "CSV exported!\n" + path);
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error exporting CSV!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void exportToPDF() {
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Generate a report first.", "Print PDF", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String title = cmbReportType.getSelectedItem().toString();
        CustomerManagementFrame.printTableToPDF(title, model);
    }
}
