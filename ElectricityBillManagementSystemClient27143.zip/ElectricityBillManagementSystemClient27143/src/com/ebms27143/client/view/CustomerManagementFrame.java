package com.ebms27143.client.view;

import com.ebms27143.client.service.RMIClientConnector;
import com.ebms27143.entity.Customer;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.font.FontRenderContext;
import java.util.List;

public class CustomerManagementFrame extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JTextField txtAccount, txtName, txtPhone, txtEmail, txtAddress;
    private JTextField txtSearch;

    public CustomerManagementFrame() {
        setTitle("Customer Management");
        setSize(980, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        getContentPane().setBackground(UITheme.BG);
        setIconImage(UITheme.createAppIcon(64));

        add(UITheme.makeHeader("C", "Customer Management", "Add, update and manage electricity customers"), BorderLayout.NORTH);

        // ── CENTER: search + table ──
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(UITheme.BG);
        center.setBorder(new EmptyBorder(12, 14, 0, 14));

        txtSearch = UITheme.makeField(20);
        txtSearch.setPreferredSize(new Dimension(260, 34));
        JButton btnSearch = UITheme.solidBtn("Search", UITheme.BLUE, UITheme.WHITE);
        center.add(UITheme.makeSearchBar(txtSearch, btnSearch), BorderLayout.NORTH);

        model = new DefaultTableModel(new String[]{"ID", "Account No", "Name", "Phone", "Email", "Address"}, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        UITheme.styleTable(table);
        table.setAutoCreateRowSorter(true);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(UITheme.BORDER_CLR));
        scroll.getViewport().setBackground(UITheme.WHITE);
        center.add(scroll, BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        // ── SOUTH: form + buttons ──
        JPanel south = new JPanel(new BorderLayout(0, 8));
        south.setBackground(UITheme.BG);
        south.setBorder(new EmptyBorder(10, 14, 10, 14));

        JPanel formCard = UITheme.makeCard();
        formCard.setLayout(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(5, 8, 5, 8);
        g.fill = GridBagConstraints.HORIZONTAL;

        txtAccount = UITheme.makeField(14); txtName = UITheme.makeField(14);
        txtPhone   = UITheme.makeField(14); txtEmail = UITheme.makeField(14);
        txtAddress = UITheme.makeField(14);

        addFormRow(formCard, g, 0, "Account No:", txtAccount, "Name:", txtName);
        addFormRow(formCard, g, 1, "Phone:",      txtPhone,   "Email:", txtEmail);

        g.gridx = 0; g.gridy = 2; formCard.add(UITheme.fieldLabel("Address:"), g);
        g.gridx = 1; g.gridwidth = 3; formCard.add(txtAddress, g);
        g.gridwidth = 1;

        south.add(UITheme.sectionLabel("Customer Details"), BorderLayout.NORTH);
        south.add(formCard, BorderLayout.CENTER);

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 6));
        btnRow.setBackground(UITheme.BG);
        JButton btnAdd    = UITheme.solidBtn("Add",          UITheme.GREEN,                UITheme.WHITE);
        JButton btnUpdate = UITheme.solidBtn("Update",        UITheme.BLUE,                 UITheme.WHITE);
        JButton btnDelete = UITheme.solidBtn("Delete",        UITheme.RED,                  UITheme.WHITE);
        JButton btnRefresh= UITheme.solidBtn("Refresh",       UITheme.NAVY,                 UITheme.WHITE);
        JButton btnCSV    = UITheme.outlineBtn("Export CSV",  UITheme.BLUE);
        JButton btnPDF    = UITheme.solidBtn("Print PDF",     new Color(120, 40, 200),       UITheme.WHITE);
        JButton btnBills  = UITheme.solidBtn("Manage Bills",  UITheme.BLUE,                 UITheme.WHITE);
        btnRow.add(btnAdd); btnRow.add(btnUpdate); btnRow.add(btnDelete);
        btnRow.add(btnRefresh); btnRow.add(btnCSV); btnRow.add(btnPDF); btnRow.add(btnBills);
        south.add(btnRow, BorderLayout.SOUTH);

        // Wrap south + status bar so they don't overwrite each other
        JPanel southWrapper = new JPanel(new BorderLayout());
        southWrapper.setBackground(UITheme.BG);
        southWrapper.add(south, BorderLayout.CENTER);
        southWrapper.add(UITheme.makeStatusBar("Electricity Bill Management System  |  Customer Management"), BorderLayout.SOUTH);
        add(southWrapper, BorderLayout.SOUTH);

        // Actions
        btnAdd.addActionListener(e -> addCustomer());
        btnUpdate.addActionListener(e -> updateCustomer());
        btnDelete.addActionListener(e -> deleteCustomer());
        btnRefresh.addActionListener(e -> loadCustomers());
        btnCSV.addActionListener(e -> exportToCSV());
        btnPDF.addActionListener(e -> exportToPDF());
        btnBills.addActionListener(e -> new BillManagementFrame().setVisible(true));
        btnSearch.addActionListener(e -> searchCustomers(txtSearch.getText()));
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) populateForm(); });

        loadCustomers();
    }

    private void addFormRow(JPanel p, GridBagConstraints g, int row,
                            String l1, JComponent f1, String l2, JComponent f2) {
        g.gridx = 0; g.gridy = row; p.add(UITheme.fieldLabel(l1), g);
        g.gridx = 1; p.add(f1, g);
        g.gridx = 2; p.add(UITheme.fieldLabel(l2), g);
        g.gridx = 3; p.add(f2, g);
    }

    private void populateForm() {
        int row = table.getSelectedRow();
        if (row == -1) return;
        txtAccount.setText(model.getValueAt(row, 1).toString());
        txtName.setText(model.getValueAt(row, 2).toString());
        txtPhone.setText(model.getValueAt(row, 3).toString());
        txtEmail.setText(model.getValueAt(row, 4).toString());
        txtAddress.setText(model.getValueAt(row, 5).toString());
    }

    private void loadCustomers() {
        try {
            model.setRowCount(0);
            for (Customer c : RMIClientConnector.getService().getAllCustomers()) addRow(c);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading customers!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addRow(Customer c) {
        model.addRow(new Object[]{c.getId(), c.getAccountNo(), c.getName(), c.getPhone(), c.getEmail(), c.getAddress()});
    }

    private void searchCustomers(String query) {
        try {
            model.setRowCount(0);
            for (Customer c : RMIClientConnector.getService().getAllCustomers())
                if (c.getName().toLowerCase().contains(query.toLowerCase())) addRow(c);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private boolean validateForm() {
        String acc = txtAccount.getText().trim(), name = txtName.getText().trim(),
               ph  = txtPhone.getText().trim(),   em  = txtEmail.getText().trim(),
               adr = txtAddress.getText().trim();
        if (acc.isEmpty() || name.isEmpty() || ph.isEmpty() || em.isEmpty() || adr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (acc.length() != 8) {
            JOptionPane.showMessageDialog(this, "Account No must be exactly 8 characters.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!acc.matches("[A-Za-z0-9\\-]+")) {
            JOptionPane.showMessageDialog(this, "Account No: letters, numbers or hyphens only.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!name.matches("[A-Za-z \\-']+")) {
            JOptionPane.showMessageDialog(this, "Name must contain letters only (no numbers or special characters).", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (name.trim().length() < 3) {
            JOptionPane.showMessageDialog(this, "Name must be at least 3 characters.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!ph.matches("\\+?[0-9]{7,15}")) {
            JOptionPane.showMessageDialog(this, "Phone must be 7-15 digits.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!em.matches("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$")) {
            JOptionPane.showMessageDialog(this, "Enter a valid email.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (adr.trim().length() < 5) {
            JOptionPane.showMessageDialog(this, "Address must be at least 5 characters.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        if (!adr.matches("[A-Za-z0-9 ,\\.\\-/]+")) {
            JOptionPane.showMessageDialog(this, "Address contains invalid characters.", "Validation", JOptionPane.WARNING_MESSAGE); return false;
        }
        return true;
    }

    private void addCustomer() {
        if (!validateForm()) return;
        try {
            Customer c = new Customer();
            c.setAccountNo(txtAccount.getText().trim()); c.setName(txtName.getText().trim());
            c.setPhone(txtPhone.getText().trim());       c.setEmail(txtEmail.getText().trim());
            c.setAddress(txtAddress.getText().trim());   c.setStatus("ACTIVE");
            RMIClientConnector.getService().addCustomer(c);
            loadCustomers();
            JOptionPane.showMessageDialog(this, "Customer added successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error adding customer!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void updateCustomer() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a customer first!"); return; }
        if (!validateForm()) return;
        try {
            Long id = Long.valueOf(model.getValueAt(row, 0).toString());
            Customer c = RMIClientConnector.getService().getCustomerById(id);
            c.setAccountNo(txtAccount.getText().trim()); c.setName(txtName.getText().trim());
            c.setPhone(txtPhone.getText().trim());       c.setEmail(txtEmail.getText().trim());
            c.setAddress(txtAddress.getText().trim());
            RMIClientConnector.getService().updateCustomer(c);
            loadCustomers();
            JOptionPane.showMessageDialog(this, "Customer updated successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error updating customer!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void deleteCustomer() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Select a customer first!"); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete this customer?", "Confirm", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try {
            RMIClientConnector.getService().deleteCustomer(Long.valueOf(model.getValueAt(row, 0).toString()));
            loadCustomers();
            JOptionPane.showMessageDialog(this, "Customer deleted successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error deleting customer!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void exportToCSV() {
        try {
            JFileChooser fc = new JFileChooser();
            fc.setDialogTitle("Save CSV File");
            if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
            java.io.FileWriter w = new java.io.FileWriter(fc.getSelectedFile() + ".csv");
            w.write("ID,AccountNo,Name,Phone,Email,Address\n");
            for (int i = 0; i < model.getRowCount(); i++)
                w.write(model.getValueAt(i,0)+","+model.getValueAt(i,1)+","+model.getValueAt(i,2)+","+
                        model.getValueAt(i,3)+","+model.getValueAt(i,4)+","+model.getValueAt(i,5)+"\n");
            w.close();
            JOptionPane.showMessageDialog(this, "CSV exported successfully!");
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Error exporting CSV!", "Error", JOptionPane.ERROR_MESSAGE); }
    }

    private void exportToPDF() {
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No customer data to print.", "Print PDF", JOptionPane.WARNING_MESSAGE);
            return;
        }
        printTableToPDF("Customer Report", model);
    }

    static void printTableToPDF(String reportTitle, javax.swing.table.DefaultTableModel mdl) {
        java.awt.print.PrinterJob job = java.awt.print.PrinterJob.getPrinterJob();
        java.awt.print.PageFormat pf = job.defaultPage();
        pf.setOrientation(java.awt.print.PageFormat.LANDSCAPE);

        job.setPrintable((graphics, pageFormat, pageIndex) -> {
            Graphics2D g = (Graphics2D) graphics;
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int ix = (int) pageFormat.getImageableX();
            int iy = (int) pageFormat.getImageableY();
            int iw = (int) pageFormat.getImageableWidth();
            int ih = (int) pageFormat.getImageableHeight();

            int headerH    = 52;
            int tableHdrH  = 22;
            int rowH       = 18;
            int footerH    = 18;
            int rowsPerPg  = (ih - headerH - tableHdrH - footerH) / rowH;
            int totalRows  = mdl.getRowCount();
            int colCount   = mdl.getColumnCount();
            int numPages   = Math.max(1, (totalRows + rowsPerPg - 1) / rowsPerPg);

            if (pageIndex >= numPages) return java.awt.print.Printable.NO_SUCH_PAGE;

            g.translate(ix, iy);
            int colW = iw / colCount;

            // ── Header ──
            g.setColor(new Color(10, 35, 81));
            g.setFont(new Font("Arial", Font.BOLD, 13));
            g.drawString("Electricity Bill Management System", 0, 16);
            g.setFont(new Font("Arial", Font.BOLD, 11));
            g.drawString(reportTitle, 0, 30);
            g.setFont(new Font("Arial", Font.PLAIN, 9));
            g.setColor(Color.GRAY);
            String date = new java.text.SimpleDateFormat("dd/MM/yyyy HH:mm").format(new java.util.Date());
            g.drawString("Generated: " + date + "   |   Page " + (pageIndex + 1) + " of " + numPages, 0, 44);
            g.setColor(new Color(200, 215, 230));
            g.drawLine(0, 48, iw, 48);

            // ── Table header row ──
            int tableY = headerH;
            g.setColor(new Color(10, 35, 81));
            g.fillRect(0, tableY, iw, tableHdrH);
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 9));
            for (int c = 0; c < colCount; c++) {
                g.drawString(mdl.getColumnName(c), c * colW + 5, tableY + 15);
            }

            // ── Data rows ──
            int startRow = pageIndex * rowsPerPg;
            int endRow   = Math.min(startRow + rowsPerPg, totalRows);
            g.setFont(new Font("Arial", Font.PLAIN, 9));

            for (int r = startRow; r < endRow; r++) {
                int rowY = tableY + tableHdrH + (r - startRow) * rowH;
                // Alternating background
                if ((r - startRow) % 2 == 1) {
                    g.setColor(new Color(245, 248, 253));
                    g.fillRect(0, rowY, iw, rowH);
                }
                g.setColor(new Color(22, 28, 36));
                for (int c = 0; c < colCount; c++) {
                    Object val = mdl.getValueAt(r, c);
                    if (val != null) {
                        String text = val.toString();
                        FontMetrics fm = g.getFontMetrics();
                        while (text.length() > 1 && fm.stringWidth(text) > colW - 8)
                            text = text.substring(0, text.length() - 1);
                        g.drawString(text, c * colW + 5, rowY + rowH - 4);
                    }
                }
                // Row separator
                g.setColor(new Color(220, 230, 240));
                g.drawLine(0, rowY + rowH, iw, rowY + rowH);
            }

            // ── Table border + column lines ──
            int dataH = tableHdrH + (endRow - startRow) * rowH;
            g.setColor(new Color(180, 200, 220));
            g.drawRect(0, tableY, iw, dataH);
            for (int c = 1; c < colCount; c++) {
                g.drawLine(c * colW, tableY, c * colW, tableY + dataH);
            }

            // ── Footer ──
            g.setColor(Color.GRAY);
            g.setFont(new Font("Arial", Font.PLAIN, 8));
            String footer = "Total: " + totalRows + " records   |   EBMS - AUCA INSY 7312";
            FontMetrics fm = g.getFontMetrics();
            g.drawString(footer, (iw - fm.stringWidth(footer)) / 2, ih - 4);

            return java.awt.print.Printable.PAGE_EXISTS;
        }, pf);

        javax.print.attribute.HashPrintRequestAttributeSet attrs =
                new javax.print.attribute.HashPrintRequestAttributeSet();
        attrs.add(javax.print.attribute.standard.OrientationRequested.LANDSCAPE);
        attrs.add(javax.print.attribute.standard.MediaSizeName.ISO_A4);

        if (job.printDialog(attrs)) {
            try {
                job.print(attrs);
                JOptionPane.showMessageDialog(null, "Printed successfully!", "Print PDF", JOptionPane.INFORMATION_MESSAGE);
            } catch (java.awt.print.PrinterAbortException ignored) {
            } catch (java.awt.print.PrinterException e) {
                JOptionPane.showMessageDialog(null, "Print failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
