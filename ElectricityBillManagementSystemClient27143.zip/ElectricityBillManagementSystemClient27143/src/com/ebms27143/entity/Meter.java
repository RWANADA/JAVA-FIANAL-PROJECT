/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ebms27143.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author chrik
 */

public class Meter implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    
    private String meterNumber;

    private String type; // Residential / Commercial
    private String status;

   
    private Date installDate;

    
    private Customer customer;

    
    private List<MeterReading> readings;

    public Meter() {}

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMeterNumber() {
        return meterNumber;
    }

    public void setMeterNumber(String meterNumber) {
        this.meterNumber = meterNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getInstallDate() {
        return installDate;
    }

    public void setInstallDate(Date installDate) {
        this.installDate = installDate;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public List<MeterReading> getReadings() {
        return readings;
    }

    public void setReadings(List<MeterReading> readings) {
        this.readings = readings;
    }

    @Override
    public String toString() {
        return meterNumber + " (" + type + ")";
    }

}
