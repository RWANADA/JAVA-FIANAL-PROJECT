/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ebms27143.entity;

import java.io.Serializable;


/**
 *
 * @author chrik
 */

public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    
    private String username;

    
    private String passwordHash;

    private String role;
    private String email;

   
    private OtpRecord otpRecord;

    public User() {}

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public OtpRecord getOtpRecord() {
        return otpRecord;
    }

    public void setOtpRecord(OtpRecord otpRecord) {
        this.otpRecord = otpRecord;
    }
    
}