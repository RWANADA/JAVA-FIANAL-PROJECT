/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ebms27143.entity;

import java.io.Serializable;
import java.util.Date;


/**
 *
 * @author chrik
 */

public class MeterReading implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

   
    private Date readingDate;

    private double previousUnits;
    private double currentUnits;
    private double unitsConsumed;

   
    private Meter meter;

   
    private Bill bill;

    public MeterReading() {}

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getReadingDate() {
        return readingDate;
    }

    public void setReadingDate(Date readingDate) {
        this.readingDate = readingDate;
    }

    public double getPreviousUnits() {
        return previousUnits;
    }

    public void setPreviousUnits(double previousUnits) {
        this.previousUnits = previousUnits;
    }

    public double getCurrentUnits() {
        return currentUnits;
    }

    public void setCurrentUnits(double currentUnits) {
        this.currentUnits = currentUnits;
    }

    public double getUnitsConsumed() {
        return unitsConsumed;
    }

    public void setUnitsConsumed(double unitsConsumed) {
        this.unitsConsumed = unitsConsumed;
    }

    public Meter getMeter() {
        return meter;
    }

    public void setMeter(Meter meter) {
        this.meter = meter;
    }

    public Bill getBill() {
        return bill;
    }

    public void setBill(Bill bill) {
        this.bill = bill;
    }
    
}
