/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ebms27143.entity;

import java.io.Serializable;
import java.util.Date;


/**
 *
 * @author chrik
 */

public class OtpRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String otpCode;

    
    private Date expiryTime;

    
    private User user;

    public OtpRecord() {}

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOtpCode() {
        return otpCode;
    }

    public void setOtpCode(String otpCode) {
        this.otpCode = otpCode;
    }

    public Date getExpiryTime() {
        return expiryTime;
    }

    public void setExpiryTime(Date expiryTime) {
        this.expiryTime = expiryTime;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
    
}
