/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ebms27143.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author chrik
 */

public class Tariff implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String name;
    private String category; // Residential / Commercial
    private double ratePerUnit;

   
    private Date effectiveDate;

    
    private List<Bill> bills;

    public Tariff() {}

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getRatePerUnit() {
        return ratePerUnit;
    }

    public void setRatePerUnit(double ratePerUnit) {
        this.ratePerUnit = ratePerUnit;
    }

    public Date getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(Date effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public List<Bill> getBills() {
        return bills;
    }

    public void setBills(List<Bill> bills) {
        this.bills = bills;
    }

    @Override
    public String toString() {
        return name + " (" + category + " - " + ratePerUnit + "/unit)";
    }
}